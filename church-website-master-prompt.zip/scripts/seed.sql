-- REDEEM seed data (sample content, clearly labelled as such in the UI)

TRUNCATE sermons, events, ministries, leaders,
  prayer_requests, contact_messages, newsletter_subscribers,
  event_registrations, giving_intents, volunteers RESTART IDENTITY;

/* ------------------------------ Sermons ------------------------------ */
INSERT INTO sermons (slug, title, speaker, sermon_date, scripture, category, summary, description, video_url, audio_url, thumbnail, featured) VALUES
('grace-before-the-storm', 'Grace Before the Storm', 'Pastor Daniel Mensah', '2026-02-01', 'Psalm 46:1-3', 'Faith',
 'When life feels out of control, God is still on the throne. A message about resting in grace before the storm breaks over you.',
 'Every believer meets seasons that shake their footing. In this message we return to the psalm that declares God as our refuge and strength, a very present help in trouble. We look at what it actually costs to rest in grace while the storm is still raging, and what changes in a heart that has finally stopped fighting the wave.',
 'https://videos.pexels.com/video-files/37639524/15954366_3840_2160_24fps.mp4', NULL,
 'https://images.pexels.com/photos/36425622/pexels-photo-36425622.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', TRUE),

('rooted-and-reaching', 'Rooted and Reaching', 'Pastor Daniel Mensah', '2026-02-08', 'Colossians 2:6-7', 'Spiritual Growth',
 'You cannot reach outward with what you have not grown inward. A practical study on staying rooted so you can stretch beyond your comfort.',
 'Paul urges the Colossians to live in Christ, rooted and built up in him. In this teaching we unpack what rootedness looks like in ordinary weeks: rhythm, community, Scripture and honesty before God. Then we ask the harder question: where is God inviting you to reach?',
 NULL, NULL,
 'https://images.pexels.com/photos/2774551/pexels-photo-2774551.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE),

('prayer-that-changes-rooms', 'Prayer That Changes Rooms', 'Grace Adeyemi', '2026-02-15', 'Matthew 6:5-6', 'Prayer',
 'Prayer is not a religious performance. It is the place where rooms you cannot enter yourself get opened.',
 'Jesus calls us to a private room and a closed door. This audio teaching walks through what Jesus is really teaching about the posture of prayer: secrecy, simplicity, persistence and dependence. Includes a 10-minute guided intercession for family, work and your city.',
 NULL, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
 'https://images.pexels.com/photos/6663862/pexels-photo-6663862.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE),

('made-for-more', 'Made for More', 'Samuel Okonkwo', '2026-02-22', 'Jeremiah 29:11', 'Purpose',
 'The plans God has for you are not escape plans. They are encounter plans. A message on discovering and stepping into your God-given purpose.',
 'When God spoke to the exiles, He did not promise comfort first — He promised plans. We look at how purpose is discovered not in a single lightning moment but through obedience in small things, community that sees you, and a God who has already named your name.',
 NULL, NULL,
 'https://images.pexels.com/photos/8556219/pexels-photo-8556219.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE),

('when-the-church-feels-like-home', 'When the Church Feels Like Home', 'Pastor Daniel Mensah', '2026-01-25', '1 Peter 2:4-5', 'Community',
 'The church was never designed to be a building or an audience. It is a household. A message on belonging and becoming family.',
 'Peter describes believers as living stones being built into a spiritual house. In this message we ask what a household looks like compared to a programme, and how small, imperfect people build something that feels like home. For those tired of being a spectator, this one is for you.',
 NULL, NULL,
 'https://images.pexels.com/photos/34688517/pexels-photo-34688517.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE),

('courage-for-everyday-faith', 'Courage for Everyday Faith', 'David Lin', '2026-01-18', 'Joshua 1:9', 'Faith',
 'Be strong and courageous is the hardest and most repeated command in Scripture. What does it look like when the giant is a Tuesday morning?',
 'God''s command to Joshua was repeated three times — because courage is rarely natural. We look at three everyday arenas where faith gets tested: words, work and money — and how ordinary obedience becomes extraordinary witness.',
 NULL, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
 'https://images.pexels.com/photos/5875069/pexels-photo-5875069.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE),

('the-quiet-work-of-the-spirit', 'The Quiet Work of the Spirit', 'Miriam Cohen', '2026-01-11', 'John 14:26', 'Holy Spirit',
 'Before the fire, there is the wind. Learning to recognise the quiet, consistent work of the Spirit in your inner life.',
 'Jesus promised the Spirit as a Helper, a Teacher and a Reminder. This message moves the Spirit from the loudest moments of worship into the quiet architecture of a day: conviction, comfort, correction and the slow shaping of character.',
 NULL, NULL,
 'https://images.pexels.com/photos/8383444/pexels-photo-8383444.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE),

('leading-like-jesus', 'Leading Like Jesus', 'Pastor Daniel Mensah', '2026-01-04', 'Mark 10:42-45', 'Leadership',
 'In the Kingdom, greatness is redefined. A word for every person who leads a team, a household, a ministry or a life.',
 'When the disciples argued about who was greatest, Jesus overturned the whole system. We study the servant model of leadership: authority as stewardship, influence as sacrifice, and success measured in lives lifted. A challenging message for every level of leadership.',
 NULL, NULL,
 'https://images.pexels.com/photos/15649904/pexels-photo-15649904.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1280&h=720', FALSE);

/* ------------------------------ Events ------------------------------ */
INSERT INTO events (slug, title, category, event_date, start_time, end_time, location, description, details, speaker, image, registration_open, featured) VALUES
('forward-conference', 'Forward: Worship & Leadership Conference', 'Conference', '2026-03-14', '09:00 AM', '04:00 PM', 'REDEEM Campus (sample location)',
 'One day of deep worship, bold teaching and practical leadership equipping for every area of your life.',
 'Forward is REDEEM''s annual gathering for anyone who wants to go deeper — worshipper, leader, student of Jesus. The day moves through three movements: encounter (deep worship), alignment (teaching on purpose and leadership) and send (prayer and next steps). Lunch is provided, and children''s care is available throughout the day.',
 'Guest pastors (to be confirmed)',
 'https://images.pexels.com/photos/34328512/pexels-photo-34328512.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900', TRUE, TRUE),

('prayer-and-word-night', 'Prayer & Word Night', 'Prayer Meeting', '2026-03-06', '06:00 PM', '08:00 PM', 'REDEEM Campus (sample location)',
 'A monthly night of corporate prayer, intercession and a short, pointed word.',
 'We gather to pray in the open — for our church, our families, our neighbours and our city. The evening includes guided intercession, a short teaching and a time of prayer for those who would like to stand with us. Come as you are; leave lighter than you came.',
 'REDEEM Prayer Team',
 'https://images.pexels.com/photos/6663862/pexels-photo-6663862.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900', TRUE, FALSE),

('youth-night-fire-and-freedom', 'Youth Night: Fire & Freedom', 'Youth Event', '2026-03-21', '06:30 PM', '09:00 PM', 'REDEEM Youth Hall (sample location)',
 'An electric evening for high schoolers and young adults — worship, real talk and genuine freedom.',
 'Fire & Freedom is our signature youth gathering: high-energy worship, messages that speak to real life, small-group conversation and honest prayer. Snacks are on us. Bring friends — no one gets left at the door.',
 'Youth Team',
 'https://images.pexels.com/photos/8556219/pexels-photo-8556219.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900', TRUE, FALSE),

('first-timers-breakfast', 'First-Timers Breakfast', 'Community Event', '2026-03-22', '08:30 AM', '10:00 AM', 'REDEEM Cafe (sample location)',
 'Before the Sunday service, meet the team over coffee, food and conversation. No agenda, no pressure.',
 'This is our warm-up for first-time visitors. We share breakfast, answer your questions honestly, and walk you through what to expect on Sunday. Afterwards you are welcome to join the 10:00 AM service, or just stay in touch. Every first-timer from the previous month will be personally welcomed.',
 'Hospitality Team',
 'https://images.pexels.com/photos/24023646/pexels-photo-24023646.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900', TRUE, FALSE),

('community-food-drive', 'Community Food Drive & Blessing Day', 'Outreach', '2026-04-04', '10:00 AM', '02:00 PM', 'REDEEM Campus (sample location)',
 'We pack, deliver and bless. Join our outreach team as we serve families in our community with food and dignity.',
 'Once a season, REDEEM packs hundreds of food parcels with volunteers and delivers them door to door with words of encouragement. This day is open to everyone — including first-timers who want to serve without stepping onto a stage. Volunteer teams of four are assigned routes, and we close the day with a shared lunch.',
 'Outreach & Missions Team',
 'https://images.pexels.com/photos/6995221/pexels-photo-6995221.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900', TRUE, FALSE),

('womens-grace-gather', 'Womens Grace Gather', 'Women', '2026-04-18', '10:00 AM', '12:30 PM', 'REDEEM Campus (sample location)',
 'A morning of rest, encouragement and sisterhood for the women of REDEEM and our neighbourhood.',
 'Grace Gather is a women-only morning designed for restoration: a gentle teaching, shared breakfast, open conversation tables and prayer. Children''s care is provided so you can actually rest. Bring a friend who needs encouragement.',
 'Womens Ministry Team',
 'https://images.pexels.com/photos/8445576/pexels-photo-8445576.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=900', TRUE, FALSE);

/* ------------------------------ Ministries ------------------------------ */
INSERT INTO ministries (slug, name, tagline, description, purpose, activities, meeting_info, leader_name, leader_title, image, icon_key, sort) VALUES
('childrens-ministry', 'Children''s Ministry', 'Little Lambs',
 'A safe, joyful place where children from birth to grade 6 meet Jesus in age-appropriate ways and grow up knowing they are loved.',
 'To partner with families in raising children who know, love and follow Jesus — in an environment that is safe, nurturing and genuinely fun.',
 'Sunday school during both worship services|Seasonal Bible schools and holiday camps|Family nights and kids'' communion|New-blessing (baby) celebrations',
 'Sundays, 08:00 & 10:00 AM (sample times)',
 'Miriam Cohen', 'Children''s Ministry Lead',
 'https://images.pexels.com/photos/33867307/pexels-photo-33867307.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'sun', 1),

('youth-ministry', 'Youth Ministry', 'Next Generation',
 'Where high schoolers and young adults worship boldly, ask hard questions and find a community that does not treat their faith like a joke.',
 'To walk with students as they discover an authentic faith that survives hard questions, real relationships and a culture that does not match the gospel.',
 'Monthly Fire & Freedom youth nights|Weekly small groups at schools and campuses|Summer camps and missions trips|1-on-1 mentorship and life-skill sessions',
 'Youth Night: first Friday of the month (sample)',
 'Samuel Okonkwo', 'Youth Ministry Lead',
 'https://images.pexels.com/photos/8556219/pexels-photo-8556219.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'flame', 2),

('womens-ministry', 'Womens Ministry', 'Grace Collective',
 'A sisterhood of women praying, growing and equipping one another for life in every season.',
 'To create a space where women are known, strengthened and sent — in marriage, motherhood, career, grief and everything in between.',
 'Monthly Grace Gather mornings|Bible study circle (Thursdays)|New mothers'' breakfast|Prayer & mentoring partnerships',
 'Grace Gather: 2nd Saturday of the month (sample)',
 'Grace Adeyemi', 'Womens Ministry Lead',
 'https://images.pexels.com/photos/8445576/pexels-photo-8445576.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'heart', 3),

('mens-ministry', 'Mens Ministry', 'Anchored Men',
 'Men who refuse to coast. Honest conversation, real discipleship and practical formation for the men of the church.',
 'To raise men who lead their households well, speak with integrity, carry one another''s burdens and point their families to Jesus.',
 'Monthly men''s breakfast|Leadership & mentorship circles|Marriage preparation and marriage care|Community service days',
 'Mens breakfast: last Saturday of the month (sample)',
 'David Lin', 'Mens Ministry Lead',
 'https://images.pexels.com/photos/5875069/pexels-photo-5875069.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'shield', 4),

('worship-ministry', 'Worship Ministry', 'Leading the House',
 'Singers, musicians and worship leaders who rehearse, pray and lead the congregation into the presence of God — not toward performance, but toward encounter.',
 'To raise and equip worship teams whose first priority is the presence of God and the congregational life of the church.',
 'Sunday worship leadership|Rehearsals & vocal coaching|Intercessory prayer for services|Special services and conferences',
 'Rehearsals: Saturdays 04:00 PM (sample)',
 'Grace Adeyemi', 'Worship & Creative Arts Lead',
 'https://images.pexels.com/photos/12044265/pexels-photo-12044265.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'note', 5),

('media-ministry', 'Media Ministry', 'Capturing the Moment',
 'Sound, light, video, photography and streaming — the technical crew that makes every gathering clear, warm and shareable.',
 'To use technology with excellence so that every person — in the room and online — encounters the message without distraction.',
 'Live sound & lighting|Worship and sermon production|Streaming and recording services|Social media and content',
 'Serves at all gatherings; tech call 30 minutes before (sample)',
 'David Lin', 'Media & Digital Lead',
 'https://images.pexels.com/photos/38756958/pexels-photo-38756958.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'camera', 6),

('prayer-ministry', 'Prayer Ministry', 'The Watch',
 'The heartbeat of the church. We keep watch, intercede for families, and carry the prayers of the congregation in confidential care.',
 'To lead the church in a life of corporate and personal prayer, and to stand with every person in the congregation through the seasons of life.',
 'Friday prayer meetings|Monthly Prayer & Word nights|Prayer for hospital visits and funerals|Confidential prayer request care',
 'Friday Prayer Meeting, 06:00 PM (sample)',
 'Miriam Cohen', 'Prayer Ministry Lead',
 'https://images.pexels.com/photos/6663862/pexels-photo-6663862.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'candle', 7),

('outreach-missions', 'Outreach & Missions', 'Sent, Not Just Saved',
 'We believe the gospel travels on feet. From food drives to global partnerships, we serve our city and the nations.',
 'To mobilise the church in local compassion and global mission so that every member is an ambassador of grace.',
 'Quarterly community food drives|Local partnerships with shelters and schools|Missions sending & prayer partnerships|Short-term mission trips',
 'Blessing Day: first Saturday of the quarter (sample)',
 'Miriam Cohen', 'Outreach & Missions Lead',
 'https://images.pexels.com/photos/6995221/pexels-photo-6995221.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800', 'globe', 8);

/* ------------------------------ Leaders ------------------------------ */
INSERT INTO leaders (name, role, bio, responsibility, sort) VALUES
('Daniel Mensah', 'Senior Pastor',
 'Daniel has spent fifteen years in pastoral ministry, serving in cities across two continents. He and his family lead REDEEM with one conviction: that church can be genuinely welcome, deeply biblical and radically loving at the same time.',
 'Overall pastoral leadership, preaching and the vision of REDEEM', 1),
('Grace Adeyemi', 'Worship & Creative Arts Lead',
 'Grace is a singer, songwriter and rehearsal obsessive. She has led worship in churches and conferences, and at REDEEM she raises teams that point people past the stage to the One who stands behind it.',
 'Worship teams, creative arts, special services', 2),
('Samuel Okonkwo', 'Family, Children & Youth Lead',
 'A father of four and a teacher by trade, Samuel believes every child deserves to hear the story of Jesus told in a language they understand. He leads with humour, patience and a serious long-term view of young people.' ,
 'Children''s Ministry, Youth Ministry and family discipleship', 3),
('Miriam Cohen', 'Community, Prayer & Outreach Lead',
 'Miriam has served in hospital chaplaincy and NGO leadership for over a decade. She is the voice that reminds the church to open its doors, carry its prayers to the people, and meet the city halfway.',
 'Prayer Ministry, Outreach & Missions, community partnerships', 4),
('David Lin', 'Media & Digital Ministry Lead',
 'David has worked in broadcast and live production for fifteen years. At REDEEM he leads the team that treats every Sunday like a broadcast worth watching — because it is.',
 'Media Ministry, streaming, digital communication', 5);
