/**
 * REDEEM — central site configuration.
 * Everything operational (contact, times, socials) lives here so the church
 * can update it in one place. Items marked `sample` are clearly-labelled
 * placeholders until the real details are supplied.
 */

export const site = {
  name: "REDEEM",
  legalName: "REDEEM Church",
  tagline: "A Place of Faith, Hope, Love, Transformation and Purpose",
  shortDescription:
    "REDEEM is a family of believers pursuing a deeper encounter with God, a more faithful love for people, and a life of purpose. Come as you are — you belong here.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  email: "hello@redeemchurch.org",
  emailNote: "sample contact — replace with the official church inbox",
  phone: "+1 (555) 010-2026",
  phoneNote: "sample number — replace with the official church line",
  address: {
    line1: "12 Grace Avenue, Hillview",
    city: "Your City, Your Country",
    note: "sample address — replace with the official REDEEM location",
  },
  directionsUrl: "https://www.google.com/maps/search/?api=1&query=REDEEM+Church",

  serviceTimes: {
    sample: true,
    items: [
      {
        day: "Sunday",
        label: "First Sunday Worship",
        time: "08:00 AM",
        note: "Sermon, worship & children's time",
      },
      {
        day: "Sunday",
        label: "Second Sunday Worship",
        time: "10:00 AM",
        note: "Sermon, worship & children's time",
      },
      {
        day: "Wednesday",
        label: "Midweek Service",
        time: "06:00 PM",
        note: "Teaching, prayer & communion (monthly)",
      },
      {
        day: "Friday",
        label: "Prayer Meeting",
        time: "06:00 PM",
        note: "Corporate prayer & intercession",
      },
    ],
  },

  socials: [
    { name: "Facebook", href: "https://www.facebook.com/redeemchurch" },
    { name: "Instagram", href: "https://www.instagram.com/redeemchurch" },
    { name: "YouTube", href: "https://www.youtube.com/@redeemchurch" },
    { name: "TikTok", href: "https://www.tiktok.com/@redeemchurch" },
    { name: "WhatsApp", href: "https://wa.me/15550102026" },
  ],

  verses: [
    {
      text: "Come to me, all you who are weary and burdened, and I will give you rest.",
      ref: "Matthew 11:28",
    },
    {
      text: "The Lord is my shepherd; I shall not want.",
      ref: "Psalm 23:1",
    },
    {
      text: "For where two or three gather in my name, there am I with them.",
      ref: "Matthew 18:20",
    },
    {
      text: "But those who hope in the Lord will renew their strength.",
      ref: "Isaiah 40:31",
    },
    {
      text: "You have made me glad with your salvation; Lord, the light of your presence.",
      ref: "Psalm 36:9",
    },
  ],
};

export type Site = typeof site;

/** Navigation model — single source of truth for header, footer & mobile menu. */
export const navigation = {
  home: { label: "Home", href: "/" },
  about: {
    label: "About",
    href: "/about",
    children: [
      { label: "Who We Are", href: "/about" },
      { label: "Our Story", href: "/about#story" },
      { label: "Our Vision", href: "/about#vision" },
      { label: "Our Mission", href: "/about#mission" },
      { label: "Our Values", href: "/about#values" },
      { label: "Leadership", href: "/about/leadership" },
    ],
  },
  services: { label: "Services", href: "/services" },
  sermons: { label: "Sermons", href: "/sermons" },
  events: { label: "Events", href: "/events" },
  ministries: { label: "Ministries", href: "/ministries" },
  connect: {
    label: "Connect",
    href: "/visit",
    children: [
      { label: "Plan Your Visit", href: "/visit" },
      { label: "Prayer Request", href: "/prayer" },
      { label: "Join REDEEM", href: "/join" },
      { label: "Volunteer", href: "/volunteer" },
      { label: "Contact Us", href: "/contact" },
    ],
  },
  give: { label: "Give", href: "/give" },
};

export function verseOfDay() {
  const day = Math.floor(Date.now() / 86_400_000);
  return site.verses[day % site.verses.length];
}
