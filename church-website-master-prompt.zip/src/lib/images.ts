/**
 * REDEEM imagery registry.
 * All photography is licensed stock (Pexels) used as tasteful stand-ins.
 * Replace any URL here with the church's own photography when available.
 */

const px = (id: number, w = 1600, h = 1000) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const img = {
  hero: px(36425622, 1920, 1080),
  heroAlt:
    "A gathered congregation with raised hands during a worship service at REDEEM",
  welcome: px(24023646, 1200, 1500),
  interior: px(5716362, 1600, 1000),
  stainedLight: px(15649904, 1600, 1000),
  pews: px(5986436, 1600, 1000),
  congregation: px(34688517, 1600, 1000),
  handsRaised: px(2774551, 1600, 1000),
  silhouettes: px(38756958, 1600, 1000),
  band: px(12044265, 1600, 1000),
  friends: px(8556219, 1600, 1000),
  parkFriends: px(33867307, 1600, 1000),
  women: px(8445576, 1600, 1000),
  manPraying: px(5875069, 1600, 1000),
  candles: px(6663862, 1600, 1000),
  prayCloth: px(8383444, 1600, 1000),
  foodAid: px(6995221, 1600, 1000),
  volunteers: px(6591154, 1600, 1000),
  selfieGroup: px(8910365, 1600, 1000),
  fountainFriends: px(3768884, 1600, 1000),

  // Sermon thumbnails
  sermon1: px(36425622, 1280, 720),
  sermon2: px(2774551, 1280, 720),
  sermon3: px(6663862, 1280, 720),
  sermon4: px(8556219, 1280, 720),
  sermon5: px(34688517, 1280, 720),
  sermon6: px(5875069, 1280, 720),
  sermon7: px(8383444, 1280, 720),
  sermon8: px(15649904, 1280, 720),

  // Event imagery
  eventConference: px(34328512, 1600, 900),
  eventPrayer: px(6663862, 1600, 900),
  eventYouth: px(8556219, 1600, 900),
  eventFoodDrive: px(6995221, 1600, 900),
  eventWomen: px(8445576, 1600, 900),
  eventBreakfast: px(24023646, 1600, 900),

  // Ministry imagery
  minChildren: px(33867307, 1200, 800),
  minYouth: px(8556219, 1200, 800),
  minWomen: px(8445576, 1200, 800),
  minMen: px(5875069, 1200, 800),
  minWorship: px(12044265, 1200, 800),
  minMedia: px(38756958, 1200, 800),
  minPrayer: px(6663862, 1200, 800),
  minOutreach: px(6995221, 1200, 800),
} as const;

export const sampleVideo = {
  // Stock worship footage used only as a clearly-labelled sample player
  featured: "https://videos.pexels.com/video-files/37639524/15954366_3840_2160_24fps.mp4",
};

export const sampleAudio = {
  // Sample audio files used only as clearly-labelled placeholder players
  one: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  two: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
};
