"use client";

import Link from "next/link";
import { useEffect, useRef, useState, type ReactNode } from "react";

/* Date helpers live in src/lib/format.ts (server-safe). */
export { formatDate, formatDateShort, dateParts } from "@/lib/format";

/* ------------------------------ Logo ------------------------------ */

export function Logo({
  light = false,
  small = false,
}: {
  light?: boolean;
  small?: boolean;
}) {
  return (
    <Link
      href="/"
      className="group inline-flex items-center gap-2.5"
      aria-label="REDEEM — home"
    >
      <span className="relative inline-flex items-center justify-center">
        <svg
          width={small ? 30 : 38}
          height={small ? 30 : 38}
          viewBox="0 0 40 40"
          fill="none"
          aria-hidden="true"
          className="transition-transform duration-500 group-hover:rotate-6"
        >
          <circle
            cx="20"
            cy="20"
            r="18.5"
            stroke="currentColor"
            strokeWidth="1.4"
            className={light ? "text-gold-400" : "text-gold-500"}
            opacity="0.9"
          />
          <path
            d="M20 8v24"
            stroke="currentColor"
            strokeWidth="2.4"
            strokeLinecap="round"
            className="text-gold-500"
          />
          <path
            d="M12 17h16"
            stroke="currentColor"
            strokeWidth="2.4"
            strokeLinecap="round"
            className={light ? "text-cream-50" : "text-navy-800"}
          />
          <path
            d="M11 27c2.8 2.6 5.8 3.9 9 3.9s6.2-1.3 9-3.9"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            className={light ? "text-gold-300" : "text-gold-600"}
          />
        </svg>
      </span>
      <span className="leading-none">
        <span
          className={`block font-display text-2xl font-semibold tracking-[0.14em] ${
            light ? "text-cream-50" : "text-navy-900"
          }`}
        >
          REDEEM
        </span>
        <span
          className={`mt-1 block text-[0.55rem] font-bold uppercase tracking-[0.34em] ${
            light ? "text-gold-400" : "text-gold-600"
          }`}
        >
          Church
        </span>
      </span>
    </Link>
  );
}

/* ------------------------------ Reveal (scroll) ------------------------------ */

export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVisible(true);
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={`reveal ${visible ? "is-visible" : ""} ${className}`}
    >
      {children}
    </div>
  );
}

/* ------------------------------ Section heading ------------------------------ */

export function SectionHeading({
  eyebrow,
  title,
  intro,
  light = false,
  align = "left",
  className = "",
}: {
  eyebrow: string;
  title: ReactNode;
  intro?: string;
  light?: boolean;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : ""} ${className}`}
    >
      <p className={light ? "eyebrow-light" : "eyebrow"}>
        <span className="gold-hairline" aria-hidden="true" />
        {eyebrow}
        {align === "center" && (
          <span className="gold-hairline rotate-180" aria-hidden="true" />
        )}
      </p>
      <h2
        className={`mt-4 font-display text-3xl font-medium leading-[1.12] tracking-tight sm:text-4xl lg:text-[2.75rem] ${
          light ? "text-cream-50" : "text-navy-900"
        }`}
      >
        {title}
      </h2>
      {intro && (
        <p
          className={`mt-4 text-[0.975rem] leading-relaxed ${
            light ? "text-cream-100/75" : "text-ink-500"
          }`}
        >
          {intro}
        </p>
      )}
    </div>
  );
}

/* ------------------------------ Small bits ------------------------------ */

export function GoldDivider({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`} aria-hidden="true">
      <span className="h-px flex-1 bg-gradient-to-r from-transparent to-gold-500/50" />
      <svg width="9" height="9" viewBox="0 0 10 10" className="text-gold-500">
        <path d="M5 0L10 5L5 10L0 5Z" fill="currentColor" />
      </svg>
      <span className="h-px flex-1 bg-gradient-to-l from-transparent to-gold-500/50" />
    </div>
  );
}

export function SampleNote({
  children = "Sample content — replace with your official details before launch",
  dark = false,
}: {
  children?: ReactNode;
  dark?: boolean;
}) {
  return (
    <p className={`text-xs leading-relaxed ${dark ? "text-cream-100/50" : "text-ink-300"}`}>
      <span className={dark ? "sample-badge-dark" : "sample-badge"}>Sample</span>{" "}
      <span className="ml-1.5 align-middle">{children}</span>
    </p>
  );
}

export function ArrowIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg
      className={`transition-transform duration-300 group-hover:translate-x-1 ${className}`}
      viewBox="0 0 20 20"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M3 10h13m0 0-5-5m5 5-5 5"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function CheckIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="10.5" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="m8 12.2 2.6 2.6L16 9.4"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function PlayIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M8 5.5v13a1 1 0 0 0 1.52.86l10.2-6.5a1 1 0 0 0 0-1.7L9.52 4.63A1 1 0 0 0 8 5.5Z" />
    </svg>
  );
}

export const iconPaths: Record<string, ReactNode> = {
  pin: <path d="M12 21s-6.5-5.4-6.5-10.2A6.5 6.5 0 0 1 12 4.3a6.5 6.5 0 0 1 6.5 6.5C18.5 15.6 12 21 12 21Zm0-8.2a2.1 2.1 0 1 0 0-4.2 2.1 2.1 0 0 0 0 4.2Z" />,
  play: <path d="M8 5.8v12.4a.8.8 0 0 0 1.22.68l9.9-6.2a.8.8 0 0 0 0-1.36l-9.9-6.2A.8.8 0 0 0 8 5.8Z" />,
  candle: <path d="M12 3.2c.9 1.1 1.6 2 1.6 3a1.9 1.9 0 0 1-3.2 1.3C10.5 6.1 11.3 5 12 3.2ZM10 10.5h4a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-8.5a1 1 0 0 1 1-1Z" />,
  calendar: <path d="M5 6.5h14a1 1 0 0 1 1 1V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7.5a1 1 0 0 1 1-1Zm0 4.5h14M8.5 4v3.5m7-3.5v3.5" />,
  heart: <path d="M12 19.8 4.9 12.7a4.4 4.4 0 0 1 6.2-6.2l.9.9.9-.9a4.4 4.4 0 1 1 6.2 6.2L12 19.8Z" />,
  mail: <path d="M4 6h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm0 1 8 6 8-6" />,
  phone: <path d="M6.8 4h2.7l1.4 3.8-2 1.5a11 11 0 0 0 5.8 5.8l1.5-2 3.8 1.4v2.7a1.5 1.5 0 0 1-1.6 1.5C11.4 18.1 5.9 12.6 5.3 5.6A1.5 1.5 0 0 1 6.8 4Z" />,
  sun: <path d="M12 16.2a4.2 4.2 0 1 0 0-8.4 4.2 4.2 0 0 0 0 8.4ZM12 3.5v1.8m0 13.4v1.8m8.5-8.5h-1.8M5.3 12H3.5m13.9-5.9-1.3 1.3M8.9 15.1l-1.3 1.3m11.8 0-1.3-1.3M8.9 8.9 7.6 7.6" />,
  flame: <path d="M12 21c-3.6 0-6-2.3-6-5.5 0-2.5 1.6-4.2 2.8-5.9C9.8 8.2 10.7 6.6 10.5 4c2.6 1.2 4 3.2 4 5.4 1-.4 1.5-1.2 1.7-2.2 1.4 1.7 1.8 3.6 1.8 5.3 0 4.6-2.4 8.5-6 8.5Zm0-2.6c1.5 0 2.6-1.1 2.6-2.7 0-1.3-.8-2.3-1.7-3.4-.9 1.1-3.5 2.9-3.5 4.6 0 1.2.9 1.5 2.6 1.5Z" />,
  shield: <path d="M12 3.5 19 6v5.3c0 4.6-3 7.6-7 9.2-4-1.6-7-4.6-7-9.2V6l7-2.5Zm-3 8 2.3 2.3L15.5 8.6" />,
  note: <path d="M9 17.6V6.8l9-2.2v10.6M9 17.6a2.6 2.6 0 1 1-2.4-2.8 2.6 2.6 0 0 1 2.4 2.8Zm9-2.4a2.6 2.6 0 1 1-2.4-2.8 2.6 2.6 0 0 1 2.4 2.8Z" />,
  camera: <path d="M4.5 7.5h3l1.5-2h6l1.5 2h3a1 1 0 0 1 1 1V18a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1V8.5a1 1 0 0 1 1-1Zm7.5 9a3.4 3.4 0 1 0 0-6.8 3.4 3.4 0 0 0 0 6.8Z" />,
  globe: <path d="M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Zm-8.4-4h16.8M5.2 8h13.6M12 3.5c2.3 2.3 3.5 5.2 3.5 8.5s-1.2 6.2-3.5 8.5c-2.3-2.3-3.5-5.2-3.5-8.5S9.7 5.8 12 3.5Z" />,
  hand: <path d="M12 4.5c.8-1 2.3-1 3 .2.4.8.2 1.8-.2 2.6l-1 1.9c1.7-.7 3.7-.5 5.2.7 1.9 1.6 1.6 4.3-.1 5.9-1.3 1.2-2.8 1.9-4.6 2.4l-3 1a3.4 3.4 0 0 1-2.3-.1l-2.5-1a4.6 4.6 0 0 1-1.2-8L9 8.9c.4-1.4.6-2.9 3-4.4Z" />,
};

export function MiniIcon({
  name,
  className = "h-6 w-6",
}: {
  name: string;
  className?: string;
}) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconPaths[name] ?? iconPaths.heart}
    </svg>
  );
}
