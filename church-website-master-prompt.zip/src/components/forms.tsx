"use client";

import { useState, type FormEvent, type ReactNode } from "react";
import { CheckIcon } from "./ui";

const field =
  "w-full rounded-xl border border-navy-900/15 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-ink-300 transition focus:border-gold-500 focus:outline-none focus:ring-2 focus:ring-gold-500/25";
const label =
  "mb-1.5 block text-[0.68rem] font-bold uppercase tracking-[0.16em] text-ink-500";

type Status = "idle" | "loading" | "success" | "error";

async function submitForm(
  kind: string,
  payload: Record<string, unknown>,
  honeypot: string,
): Promise<{ ok: boolean }> {
  try {
    const res = await fetch("/api/forms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, payload, company: honeypot }),
    });
    const data = (await res.json()) as { ok: boolean };
    return { ok: data.ok && res.ok };
  } catch {
    return { ok: false };
  }
}

function StatusPanel({
  status,
  successTitle,
  successBody,
  errorBody,
}: {
  status: Status;
  successTitle: string;
  successBody: string;
  errorBody: string;
}) {
  if (status === "success") {
    return (
      <div
        role="status"
        className="flex items-start gap-3 rounded-xl border border-gold-500/40 bg-gold-100/60 p-5"
      >
        <span className="mt-0.5 text-gold-600">
          <CheckIcon className="h-6 w-6" />
        </span>
        <span>
          <span className="block font-display text-lg text-navy-900">
            {successTitle}
          </span>
          <span className="mt-1 block text-sm leading-relaxed text-ink-700">
            {successBody}
          </span>
        </span>
      </div>
    );
  }
  if (status === "error") {
    return (
      <div
        role="alert"
        className="rounded-xl border border-red-800/25 bg-red-50 p-4 text-sm leading-relaxed text-red-900"
      >
        {errorBody}
      </div>
    );
  }
  return null;
}

function Honeypot({ value }: { value: string }) {
  return (
    <div className="hidden" aria-hidden="true">
      <label htmlFor="company">Company</label>
      <input
        id="company"
        name="company"
        type="text"
        tabIndex={-1}
        autoComplete="off"
        value={value}
        onChange={() => {}}
      />
    </div>
  );
}

/* ------------------------------ Prayer form ------------------------------ */

export function PrayerForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    category: "General",
    message: "",
    anonymous: false,
    consent: false,
    company: "",
  });

  const set = (k: string, v: string | boolean) =>
    setForm((f) => ({ ...f, [k]: v }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (form.consent) {
      setForm((f) => ({ ...f, name: "Anonymous" }));
    }
    setStatus("loading");
    const { ok } = await submitForm("prayer", { ...form, consent: form.consent }, form.company);
    setStatus(ok ? "success" : "error");
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5" noValidate>
      <StatusPanel
        status={status}
        successTitle="Your prayer has been received"
        successBody="Thank you for trusting us with this. Your request is handled privately and shared publicly only if you explicitly consent."
        errorBody="Something went wrong sending your prayer request. Please check your connection and try again, or email us directly."
      />
      {status !== "success" && (
        <>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className={label} htmlFor="p-name">Name</label>
              <input
                id="p-name"
                className={field}
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
                placeholder="Your name"
                required
                autoComplete="name"
              />
            </div>
            <div>
              <label className={label} htmlFor="p-email">Email</label>
              <input
                id="p-email"
                type="email"
                className={field}
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                placeholder="you@example.com"
                required
                autoComplete="email"
              />
            </div>
            <div>
              <label className={label} htmlFor="p-phone">Phone <span className="normal-case text-ink-300">(optional)</span></label>
              <input
                id="p-phone"
                type="tel"
                className={field}
                value={form.phone}
                onChange={(e) => set("phone", e.target.value)}
                placeholder="+1 555 000 0000"
                autoComplete="tel"
              />
            </div>
            <div>
              <label className={label} htmlFor="p-category">Prayer category</label>
              <select
                id="p-category"
                className={field}
                value={form.category}
                onChange={(e) => set("category", e.target.value)}
              >
                {["General", "Healing & Health", "Family & Relationships", "Spiritual Growth", "Financial", "Career & Work", "Guidance & Direction", "Thanksgiving"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className={label} htmlFor="p-message">Your prayer request</label>
            <textarea
              id="p-message"
              rows={5}
              className={field}
              value={form.message}
              onChange={(e) => set("message", e.target.value)}
              placeholder="Share what's on your heart…"
              required
            />
          </div>
          <div className="space-y-3">
            <label className="flex cursor-pointer items-start gap-3 text-sm text-ink-700">
              <input
                type="checkbox"
                checked={form.anonymous}
                onChange={(e) => set("anonymous", e.target.checked)}
                className="mt-0.5 h-4 w-4 accent-[#c9a227]"
              />
              I would like to be prayed for anonymously
            </label>
            <label className="flex cursor-pointer items-start gap-3 text-sm text-ink-700">
              <input
                type="checkbox"
                checked={form.consent}
                onChange={(e) => set("consent", e.target.checked)}
                className="mt-0.5 h-4 w-4 accent-[#c9a227]"
                required
              />
              I consent to REDEEM storing this information privately so our
              prayer team can pray with me
            </label>
          </div>
          <Honeypot value={form.company} />
          <button
            type="submit"
            className="btn-gold w-full sm:w-auto"
            disabled={status === "loading"}
          >
            {status === "loading" ? "Sending…" : "Submit Prayer Request"}
          </button>
        </>
      )}
    </form>
  );
}

/* ------------------------------ Contact form ------------------------------ */

export function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "General enquiry",
    message: "",
    company: "",
  });
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const { ok } = await submitForm("contact", form, form.company);
    setStatus(ok ? "success" : "error");
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5" noValidate>
      <StatusPanel
        status={status}
        successTitle="Message sent"
        successBody="Thank you for reaching out. Our team typically responds within two business days."
        errorBody="We couldn't send your message. Please try again or email us directly."
      />
      {status !== "success" && (
        <>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className={label} htmlFor="c-name">Name</label>
              <input id="c-name" className={field} value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" required autoComplete="name" />
            </div>
            <div>
              <label className={label} htmlFor="c-email">Email</label>
              <input id="c-email" type="email" className={field} value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" required autoComplete="email" />
            </div>
            <div>
              <label className={label} htmlFor="c-phone">Phone <span className="normal-case text-ink-300">(optional)</span></label>
              <input id="c-phone" type="tel" className={field} value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+1 555 000 0000" autoComplete="tel" />
            </div>
            <div>
              <label className={label} htmlFor="c-subject">Subject</label>
              <select id="c-subject" className={field} value={form.subject} onChange={(e) => set("subject", e.target.value)}>
                {["General enquiry", "First-time visit", "Pastoral support", "Volunteering", "Media & content", "Other"].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className={label} htmlFor="c-message">Message</label>
            <textarea id="c-message" rows={5} className={field} value={form.message} onChange={(e) => set("message", e.target.value)} placeholder="How can we help?" required />
          </div>
          <Honeypot value={form.company} />
          <button type="submit" className="btn-gold w-full sm:w-auto" disabled={status === "loading"}>
            {status === "loading" ? "Sending…" : "Send Message"}
          </button>
        </>
      )}
    </form>
  );
}

/* ------------------------------ Volunteer form ------------------------------ */

export function VolunteerForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    ministry: "General / not sure yet",
    availability: "Sundays",
    motivation: "",
    company: "",
  });
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const { ok } = await submitForm("volunteer", form, form.company);
    setStatus(ok ? "success" : "error");
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5" noValidate>
      <StatusPanel
        status={status}
        successTitle="Thank you for serving"
        successBody="Your details have been received. A member of our volunteer team will be in touch to show you around."
        errorBody="We couldn't send your details. Please try again or email us directly."
      />
      {status !== "success" && (
        <>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className={label} htmlFor="v-name">Name</label>
              <input id="v-name" className={field} value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" required />
            </div>
            <div>
              <label className={label} htmlFor="v-email">Email</label>
              <input id="v-email" type="email" className={field} value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" required />
            </div>
            <div>
              <label className={label} htmlFor="v-phone">Phone <span className="normal-case text-ink-300">(optional)</span></label>
              <input id="v-phone" type="tel" className={field} value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+1 555 000 0000" />
            </div>
            <div>
              <label className={label} htmlFor="v-ministry">Ministry of interest</label>
              <select id="v-ministry" className={field} value={form.ministry} onChange={(e) => set("ministry", e.target.value)}>
                {["General / not sure yet", "Children", "Youth", "Women", "Men", "Worship", "Media", "Prayer", "Outreach & Missions"].map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={label} htmlFor="v-availability">Availability</label>
              <select id="v-availability" className={field} value={form.availability} onChange={(e) => set("availability", e.target.value)}>
                {["Sundays", "Weekdays", "Weekends", "Flexible"].map((a) => (
                  <option key={a}>{a}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className={label} htmlFor="v-motivation">Why do you want to serve?</label>
            <textarea id="v-motivation" rows={4} className={field} value={form.motivation} onChange={(e) => set("motivation", e.target.value)} placeholder="Share a sentence or two about what draws you to serve…" />
          </div>
          <Honeypot value={form.company} />
          <button type="submit" className="btn-gold w-full sm:w-auto" disabled={status === "loading"}>
            {status === "loading" ? "Sending…" : "Apply to Volunteer"}
          </button>
        </>
      )}
    </form>
  );
}

/* ------------------------------ Registration form ------------------------------ */

export function RegisterForm({ eventTitle }: { eventTitle: string }) {
  const [status, setStatus] = useState<Status>("idle");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    attendees: 1,
    notes: "",
    company: "",
  });
  const set = (k: string, v: string | number) => setForm((f) => ({ ...f, [k]: v }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const { ok } = await submitForm("registration", form, form.company);
    setStatus(ok ? "success" : "error");
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5" noValidate>
      <StatusPanel
        status={status}
        successTitle="You're on the list"
        successBody={`Thank you — we've reserved your place at “${eventTitle}”. A confirmation email is on its way.`}
        errorBody="Registration didn't go through. Please try again in a moment."
      />
      {status !== "success" && (
        <>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className={label} htmlFor="r-name">Full name</label>
              <input id="r-name" className={field} value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" required />
            </div>
            <div>
              <label className={label} htmlFor="r-email">Email</label>
              <input id="r-email" type="email" className={field} value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" required />
            </div>
            <div>
              <label className={label} htmlFor="r-phone">Phone <span className="normal-case text-ink-300">(optional)</span></label>
              <input id="r-phone" type="tel" className={field} value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+1 555 000 0000" />
            </div>
            <div>
              <label className={label} htmlFor="r-attendees">How many attending?</label>
              <input
                id="r-attendees"
                type="number"
                min={1}
                max={20}
                className={field}
                value={form.attendees}
                onChange={(e) => set("attendees", Number(e.target.value) || 1)}
              />
            </div>
          </div>
          <div>
            <label className={label} htmlFor="r-notes">Anything we should know? <span className="normal-case text-ink-300">(optional)</span></label>
            <textarea id="r-notes" rows={3} className={field} value={form.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Dietary needs, accessibility, children…" />
          </div>
          <Honeypot value={form.company} />
          <button type="submit" className="btn-gold w-full sm:w-auto" disabled={status === "loading"}>
            {status === "loading" ? "Reserving…" : "Register Now"}
          </button>
        </>
      )}
    </form>
  );
}

/* ------------------------------ Give form ------------------------------ */

const amounts = [25, 50, 100, 250];

export function GiveForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [frequency, setFrequency] = useState("one-time");
  const [amount, setAmount] = useState(100);
  const [custom, setCustom] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    fund: "General Fund",
    note: "",
    company: "",
  });
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const { ok } = await submitForm(
      "give",
      {
        ...form,
        frequency,
        amount: custom ? Number(custom) : amount,
      },
      form.company,
    );
    setStatus(ok ? "success" : "error");
  }

  return (
    <form onSubmit={onSubmit} className="space-y-6" noValidate>
      <StatusPanel
        status={status}
        successTitle="Thank you for your generosity"
        successBody="Your giving intention has been recorded. A secure payment link will be sent to you by email once online giving is connected."
        errorBody="We couldn't record your giving intention. Please try again."
      />
      {status !== "success" && (
        <>
          <div>
            <span className={label}>Frequency</span>
            <div className="grid grid-cols-4 gap-2" role="group" aria-label="Giving frequency">
              {[
                ["one-time", "One-Time"],
                ["monthly", "Monthly"],
                ["quarterly", "Quarterly"],
                ["yearly", "Yearly"],
              ].map(([val, lab]) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setFrequency(val)}
                  aria-pressed={frequency === val}
                  className={`rounded-full border px-2 py-2.5 text-xs font-bold tracking-wide transition ${
                    frequency === val
                      ? "border-gold-500 bg-gold-500 text-navy-950"
                      : "border-navy-900/15 bg-white text-ink-500 hover:border-gold-500/60"
                  }`}
                >
                  {lab}
                </button>
              ))}
            </div>
          </div>
          <div>
            <span className={label}>Amount (USD)</span>
            <div className="grid grid-cols-4 gap-2" role="group" aria-label="Amount">
              {amounts.map((a) => (
                <button
                  key={a}
                  type="button"
                  onClick={() => {
                    setAmount(a);
                    setCustom("");
                  }}
                  aria-pressed={amount === a && !custom}
                  className={`rounded-xl border py-3 text-sm font-bold transition ${
                    amount === a && !custom
                      ? "border-gold-500 bg-gold-500 text-navy-950"
                      : "border-navy-900/15 bg-white text-ink-700 hover:border-gold-500/60"
                  }`}
                >
                  ${a}
                </button>
              ))}
            </div>
            <input
              type="number"
              min={1}
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              className={`${field} mt-2`}
              placeholder="Or enter a custom amount"
              aria-label="Custom amount"
            />
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className={label} htmlFor="g-fund">Designate to</label>
              <select id="g-fund" className={field} value={form.fund} onChange={(e) => set("fund", e.target.value)}>
                {["General Fund", "Missions & Outreach", "Building Fund", "Benevolence", "Media & Technology"].map((f) => (
                  <option key={f}>{f}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={label} htmlFor="g-name">Name</label>
              <input id="g-name" className={field} value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" required />
            </div>
            <div className="sm:col-span-2">
              <label className={label} htmlFor="g-email">Email</label>
              <input id="g-email" type="email" className={field} value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" required />
            </div>
            <div className="sm:col-span-2">
              <label className={label} htmlFor="g-note">Dedication or note <span className="normal-case text-ink-300">(optional)</span></label>
              <input id="g-note" className={field} value={form.note} onChange={(e) => set("note", e.target.value)} placeholder="e.g. In memory of…" />
            </div>
          </div>
          <Honeypot value={form.company} />
          <button type="submit" className="btn-gold w-full sm:w-auto" disabled={status === "loading"}>
            {status === "loading" ? "Recording…" : "Record My Gift"}
          </button>
          <p className="text-xs leading-relaxed text-ink-300">
            No card is charged on this page and no payment details are stored
            here. REDEEM will connect a trusted, PCI-compliant payment
            processor before launch — you'll receive a secure payment link.
          </p>
        </>
      )}
    </form>
  );
}

/* ------------------------------ Newsletter ------------------------------ */

export function NewsletterForm({ compact = false }: { compact?: boolean }) {
  const [status, setStatus] = useState<Status>("idle");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const { ok } = await submitForm("newsletter", { email }, company);
    setStatus(ok ? "success" : "error");
    if (ok) setEmail("");
  }

  if (status === "success") {
    return (
      <div role="status" className={`flex items-center gap-2.5 text-sm font-semibold ${compact ? "text-gold-300" : "text-gold-700"}`}>
        <CheckIcon className="h-5 w-5" />
        You're in — welcome to the family.
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="w-full" noValidate>
      <div className="flex flex-col gap-2 sm:flex-row">
        <label htmlFor="nl-email" className="sr-only">
          Email address
        </label>
        <input
          id="nl-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your email address"
          required
          className={`${compact ? "w-full rounded-full border border-cream-50/25 bg-navy-900/60 px-5 py-3 text-sm text-cream-50 placeholder:text-cream-100/40" : "w-full rounded-full border border-navy-900/15 bg-white px-5 py-3 text-sm text-ink-900 placeholder:text-ink-300"} focus:border-gold-500 focus:outline-none focus:ring-2 focus:ring-gold-500/25`}
        />
        <button type="submit" disabled={status === "loading"} className={compact ? "btn-gold shrink-0" : "btn-dark shrink-0"}>
          {status === "loading" ? "Joining…" : "Subscribe"}
        </button>
      </div>
      {status === "error" && (
        <p role="alert" className={`mt-2 text-xs ${compact ? "text-gold-300" : "text-red-800"}`}>
          Couldn't subscribe — please check your email and try again.
        </p>
      )}
      <div className="hidden" aria-hidden="true">
        <label htmlFor="nl-company">Company</label>
        <input id="nl-company" tabIndex={-1} autoComplete="off" value={company} onChange={(e) => setCompany(e.target.value)} />
      </div>
    </form>
  );
}
