import Link from "next/link";
import { NewsletterForm } from "./forms";
import { Logo } from "./ui";
import { site, navigation } from "@/lib/site";

const socialIcons: Record<string, string> = {
  Facebook: "M13.5 21v-7h2.4l.4-2.8h-2.8V9.4c0-.8.3-1.4 1.5-1.4h1.4V5.5c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.7v2.1H8.1V14h2.4v7h3Z",
  Instagram:
    "M12 8.4a3.6 3.6 0 1 0 0 7.2 3.6 3.6 0 0 0 0-7.2Zm0 5.9a2.3 2.3 0 1 1 0-4.6 2.3 2.3 0 0 1 0 4.6ZM16.9 8.2a.84.84 0 1 1-1.68 0 .84.84 0 0 1 1.68 0ZM12 4.6c-2 0-2.3 0-3.1.05a5.6 5.6 0 0 0-1.9.35 3.9 3.9 0 0 0-2.1 2.1 5.6 5.6 0 0 0-.36 1.9C4.5 9.7 4.5 10 4.5 12s0 2.3.05 3.1c.02.7.13 1.3.36 1.9a3.9 3.9 0 0 0 2.1 2.1c.6.23 1.2.34 1.9.36.8.05 1.1.05 3.1.05s2.3 0 3.1-.05c.7-.02 1.3-.13 1.9-.36a3.9 3.9 0 0 0 2.1-2.1c.23-.6.34-1.2.36-1.9.05-.8.05-1.1.05-3.1s0-2.3-.05-3.1a5.6 5.6 0 0 0-.36-1.9 3.9 3.9 0 0 0-2.1-2.1 5.6 5.6 0 0 0-1.9-.35C14.3 4.6 14 4.6 12 4.6Z",
  YouTube:
    "M20.6 8.2a2.3 2.3 0 0 0-1.6-1.6C17.5 6.2 12 6.2 12 6.2s-5.5 0-7 .4A2.3 2.3 0 0 0 3.4 8.2 24.5 24.5 0 0 0 3 12c0 1.3.13 2.6.4 3.8a2.3 2.3 0 0 0 1.6 1.6c1.5.4 7 .4 7 .4s5.5 0 7-.4a2.3 2.3 0 0 0 1.6-1.6c.27-1.2.4-2.5.4-3.8s-.13-2.6-.4-3.8ZM10.2 14.6V9.4l4.7 2.6-4.7 2.6Z",
  TikTok:
    "M16.8 5.9a4.7 4.7 0 0 1-1.1-1.5h-2.8v10.9a2.5 2.5 0 1 1-2.5-2.5c.26 0 .5.04.75.1V9.9a5.3 5.3 0 0 0-.75-.05 5.3 5.3 0 1 0 5.3 5.3V9.4a7.5 7.5 0 0 0 4.2 1.3V7.9a4.7 4.7 0 0 1-3.1-2Z",
  WhatsApp:
    "M12 4a8 8 0 0 0-6.9 12l-1 3.9 4-1A8 8 0 1 0 12 4Zm4.6 11.3c-.2.6-1.2 1.1-1.7 1.2-.4.1-1 .1-1.6-.1-2.6-.8-4.3-2.9-5-3.9-.5-.8-1-1.7-.9-2.7.1-.6.5-1.6 1.1-1.7h.6c.2 0 .4 0 .6.5l.7 1.7c.1.2 0 .4-.1.5l-.4.5c-.1.2-.3.3-.1.6a6.5 6.5 0 0 0 3 2.7c.3.1.4.1.6-.1l.5-.6c.2-.2.3-.2.6-.1l1.6.8c.3.1.5.2.5.4a2.3 2.3 0 0 1-.5 1.3Z",
};

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-navy-950 pb-24 text-cream-100/70 md:pb-0">
      {/* Newsletter band */}
      <div className="border-b border-cream-50/10">
        <div className="container-redeem flex flex-col gap-6 py-12 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-md">
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Stay Connected
            </p>
            <h2 className="mt-3 font-display text-2xl font-medium text-cream-50 sm:text-3xl">
              Encouragement for the week, straight to your inbox.
            </h2>
            <p className="mt-2 text-sm text-cream-100/60">
              One thoughtful email a week — sermon highlights, upcoming events
              and prayer themes. No noise.
            </p>
          </div>
          <div className="w-full max-w-md">
            <NewsletterForm compact />
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="container-redeem grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo light />
          <p className="mt-5 text-sm leading-relaxed text-cream-100/60">
            {site.shortDescription}
          </p>
          <ul className="mt-6 flex gap-2.5" aria-label="Social media">
            {site.socials.map((s) => (
              <li key={s.name}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.name}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-cream-50/15 text-cream-100/70 transition-all hover:-translate-y-0.5 hover:border-gold-400 hover:text-gold-400"
                >
                  <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden="true">
                    <path d={socialIcons[s.name]} />
                  </svg>
                </a>
              </li>
            ))}
          </ul>
        </div>

        <nav aria-label="Footer — explore">
          <h3 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
            Explore
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {[
              { label: "About REDEEM", href: "/about" },
              { label: "Leadership", href: "/about/leadership" },
              { label: "Services", href: "/services" },
              { label: "Sermons", href: "/sermons" },
              { label: "Events", href: "/events" },
              { label: "Ministries", href: "/ministries" },
              { label: "Give", href: "/give" },
            ].map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="transition-colors hover:text-gold-300">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Footer — get connected">
          <h3 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
            Get Connected
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {navigation.connect.children.map((c) => (
              <li key={c.href}>
                <Link href={c.href} className="transition-colors hover:text-gold-300">
                  {c.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-5">
            <h4 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
              Service Times
            </h4>
            <ul className="mt-3 space-y-1.5 text-xs text-cream-100/60">
              {site.serviceTimes.items.map((t) => (
                <li key={t.label} className="flex justify-between gap-3">
                  <span>
                    {t.day} · {t.time}
                  </span>
                  <span className="text-cream-100/40">{t.label}</span>
                </li>
              ))}
              <li className="pt-1 text-[0.62rem] uppercase tracking-widest text-cream-100/35">
                Sample times — confirm with the church
              </li>
            </ul>
          </div>
        </nav>

        <div>
          <h3 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
            Contact
          </h3>
          <address className="mt-4 space-y-2.5 text-sm not-italic text-cream-100/60">
            <p>
              {site.address.line1}
              <br />
              {site.address.city}
            </p>
            <p>
              <a href={`mailto:${site.email}`} className="transition-colors hover:text-gold-300">
                {site.email}
              </a>
            </p>
            <p>
              <a href={`tel:${site.phone.replace(/[^+\d]/g, "")}`} className="transition-colors hover:text-gold-300">
                {site.phone}
              </a>
            </p>
          </address>
          <Link href="/prayer" className="btn-ghost-light mt-6 !px-5 !py-2.5 text-xs">
            Submit a Prayer Request
          </Link>
        </div>
      </div>

      <div className="border-t border-cream-50/10">
        <div className="container-redeem flex flex-col items-center justify-between gap-3 py-6 text-xs text-cream-100/45 sm:flex-row">
          <p>
            © {year} {site.legalName}. All rights reserved. · Faith · Hope ·
            Grace · Purpose · Community
          </p>
          <div className="flex gap-5">
            <Link href="/privacy" className="transition-colors hover:text-gold-300">
              Privacy Policy
            </Link>
            <Link href="/terms" className="transition-colors hover:text-gold-300">
              Terms
            </Link>
            <Link href="/roadmap" className="transition-colors hover:text-gold-300">
              Site Roadmap
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
