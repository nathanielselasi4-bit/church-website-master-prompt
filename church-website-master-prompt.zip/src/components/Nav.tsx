"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo, MiniIcon } from "./ui";
import { site } from "@/lib/site";

type MinistryLink = { name: string; href: string };

function Chevron({ open }: { open: boolean }) {
  return (
    <svg
      className={`h-3 w-3 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
      viewBox="0 0 12 12"
      fill="none"
      aria-hidden="true"
    >
      <path d="m2.5 4.5 3.5 3.5 3.5-3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Nav({ ministries }: { ministries: MinistryLink[] }) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  useEffect(() => {
    setMobileOpen(false);
    setOpenGroup(null);
  }, [pathname]);

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/";
    const base = href.split("#")[0];
    return pathname === base || pathname.startsWith(`${base}/`);
  };

  const dropdowns: { label: string; href: string; children: { label: string; href: string }[] }[] = [
    {
      label: "About",
      href: "/about",
      children: [
        { label: "Who We Are", href: "/about" },
        { label: "Our Story", href: "/about#story" },
        { label: "Our Vision", href: "/about#vision" },
        { label: "Our Mission", href: "/about#mission" },
        { label: "Our Values", href: "/about#values" },
        { label: "Leadership", href: "/about/leadership" },
      ],
    },
    {
      label: "Ministries",
      href: "/ministries",
      children: ministries.map((m) => ({ label: m.name, href: m.href })),
    },
    {
      label: "Connect",
      href: "/visit",
      children: [
        { label: "Plan Your Visit", href: "/visit" },
        { label: "Prayer Request", href: "/prayer" },
        { label: "Join REDEEM", href: "/join" },
        { label: "Volunteer", href: "/volunteer" },
        { label: "Contact Us", href: "/contact" },
      ],
    },
  ];

  const simpleLinks = [
    { label: "Services", href: "/services" },
    { label: "Sermons", href: "/sermons" },
    { label: "Events", href: "/events" },
  ];

  return (
    <>
      {/* Top utility strip */}
      <div className="hidden bg-navy-950 text-cream-100/80 md:block">
        <div className="container-redeem flex h-9 items-center justify-between text-[0.7rem] tracking-wide">
          <p className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-gold-500 pulse-soft" aria-hidden="true" />
            Sunday Services — 08:00 &amp; 10:00 AM
            <span className="text-cream-100/40">(sample times)</span>
          </p>
          <Link
            href="/visit"
            className="font-semibold text-gold-400 transition-colors hover:text-gold-300"
          >
            First time with us? Plan your visit →
          </Link>
        </div>
      </div>

      {/* Main bar */}
      <div
        className={`sticky top-0 z-50 border-b transition-all duration-300 ${
          scrolled
            ? "border-navy-900/10 bg-cream-50/95 shadow-[0_8px_30px_-18px_rgb(5_12_23/0.35)] backdrop-blur-md"
            : "border-transparent bg-cream-50/80 backdrop-blur-sm"
        }`}
      >
        <div className="container-redeem flex h-[4.5rem] items-center justify-between gap-4">
          <Logo />

          {/* Desktop nav */}
          <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
            <Link
              href="/"
              className={`rounded-full px-3.5 py-2 text-[0.82rem] font-bold tracking-wide transition-colors ${
                isActive("/")
                  ? "text-gold-700"
                  : "text-navy-800 hover:text-gold-700"
              }`}
            >
              Home
            </Link>

            {dropdowns.map((d) => (
              <div key={d.label} className="group relative">
                <Link
                  href={d.href}
                  className={`flex items-center gap-1 rounded-full px-3.5 py-2 text-[0.82rem] font-bold tracking-wide transition-colors ${
                    isActive(d.href)
                      ? "text-gold-700"
                      : "text-navy-800 hover:text-gold-700"
                  }`}
                >
                  {d.label}
                  <Chevron open={false} />
                </Link>
                <div className="invisible absolute left-1/2 top-full -translate-x-1/2 pt-2 opacity-0 transition-all duration-300 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  <div className="w-56 rounded-2xl border border-navy-900/8 bg-white p-2 shadow-lift">
                    {d.children.map((c) => (
                      <Link
                        key={c.href}
                        href={c.href}
                        className="block rounded-xl px-3.5 py-2.5 text-[0.82rem] font-semibold text-navy-800 transition-colors hover:bg-cream-100 hover:text-gold-700"
                      >
                        {c.label}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            ))}

            {simpleLinks.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`rounded-full px-3.5 py-2 text-[0.82rem] font-bold tracking-wide transition-colors ${
                  isActive(l.href)
                    ? "text-gold-700"
                    : "text-navy-800 hover:text-gold-700"
                }`}
              >
                {l.label}
              </Link>
            ))}

            <Link href="/give" className="btn-gold ml-3 !px-5 !py-2.5 text-[0.8rem]">
              <MiniIcon name="heart" className="h-4 w-4" />
              Give
            </Link>
          </nav>

          {/* Mobile toggle */}
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-menu"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-navy-900/15 text-navy-900 lg:hidden"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              {mobileOpen ? (
                <path d="M6 6l12 12M18 6L6 18" />
              ) : (
                <path d="M4 7h16M4 12h16M4 17h10" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu overlay */}
      {mobileOpen && (
        <div
          id="mobile-menu"
          className="fixed inset-0 z-[60] flex flex-col bg-navy-950 lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
        >
          <div className="flex h-[4.5rem] shrink-0 items-center justify-between border-b border-cream-50/10 px-5">
            <Logo light />
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Close menu"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream-50/20 text-cream-50"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>

          <nav
            aria-label="Mobile"
            className="flex-1 overflow-y-auto px-5 pb-10 pt-4"
          >
            <Link
              href="/"
              className="block border-b border-cream-50/8 py-4 font-display text-2xl text-cream-50"
            >
              Home
            </Link>

            {dropdowns.map((d) => (
              <div key={d.label} className="border-b border-cream-50/8">
                <button
                  type="button"
                  onClick={() =>
                    setOpenGroup((g) => (g === d.label ? null : d.label))
                  }
                  aria-expanded={openGroup === d.label}
                  className="flex w-full items-center justify-between py-4 text-left font-display text-2xl text-cream-50"
                >
                  {d.label}
                  <span className={openGroup === d.label ? "text-gold-400" : "text-cream-50/50"}>
                    <svg viewBox="0 0 12 12" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
                      <path d="m2.5 4.5 3.5 3.5 3.5-3.5" />
                    </svg>
                  </span>
                </button>
                {openGroup === d.label && (
                  <div className="space-y-1 pb-4 pl-3">
                    {d.children.map((c) => (
                      <Link
                        key={c.href}
                        href={c.href}
                        className="block rounded-lg px-3 py-2.5 text-[0.95rem] font-semibold text-cream-100/75 transition-colors hover:bg-cream-50/5 hover:text-gold-300"
                      >
                        {c.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {simpleLinks.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="block border-b border-cream-50/8 py-4 font-display text-2xl text-cream-50"
              >
                {l.label}
              </Link>
            ))}

            <Link href="/give" className="btn-gold mt-6 w-full text-base">
              <MiniIcon name="heart" className="h-4 w-4" />
              Give
            </Link>

            <p className="mt-8 px-2 font-display text-sm italic leading-relaxed text-cream-100/50">
              “{site.verses[0].text}” — {site.verses[0].ref}
            </p>
          </nav>
        </div>
      )}
    </>
  );
}

/* Sticky quick actions — mobile only */
export function MobileActionBar() {
  const items = [
    { label: "Visit", href: "/visit", icon: "pin" },
    { label: "Sermons", href: "/sermons", icon: "play" },
    { label: "Prayer", href: "/prayer", icon: "candle" },
    { label: "Give", href: "/give", icon: "heart", gold: true },
  ];
  return (
    <nav
      aria-label="Quick actions"
      className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t border-navy-900/10 bg-cream-50/95 backdrop-blur-md md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {items.map((it) => (
        <Link
          key={it.href}
          href={it.href}
          className={`flex flex-col items-center gap-1 py-2.5 text-[0.6rem] font-bold uppercase tracking-[0.12em] transition-colors ${
            it.gold ? "text-gold-700" : "text-navy-800"
          }`}
        >
          <MiniIcon name={it.icon} className="h-5 w-5" />
          {it.label}
        </Link>
      ))}
    </nav>
  );
}
