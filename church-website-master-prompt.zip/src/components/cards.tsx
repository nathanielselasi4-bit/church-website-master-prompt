import Image from "next/image";
import Link from "next/link";
import { MiniIcon, PlayIcon } from "./ui";
import { dateParts, formatDate } from "@/lib/format";
import type {
  events as eventsTable,
  ministries as ministriesTable,
  sermons as sermonsTable,
} from "@/db/schema";

type Sermon = typeof sermonsTable.$inferSelect;
type Event = typeof eventsTable.$inferSelect;
type Ministry = typeof ministriesTable.$inferSelect;

/* ------------------------------ Sermon card ------------------------------ */

export function SermonCard({ sermon }: { sermon: Sermon }) {
  return (
    <Link
      href={`/sermons/${sermon.slug}`}
      className="group card-surface flex flex-col overflow-hidden transition-all duration-500 hover:-translate-y-1.5 hover:shadow-lift"
    >
      <div className="relative aspect-video overflow-hidden">
        <Image
          src={sermon.thumbnail}
          alt={`Sermon — ${sermon.title}`}
          fill
          sizes="(max-width: 768px) 100vw, 33vw"
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 via-transparent to-transparent" />
        <span className="absolute left-3 top-3 rounded-full bg-navy-950/70 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.16em] text-gold-300 backdrop-blur-sm">
          {sermon.category}
        </span>
        <span className="absolute bottom-3 right-3 flex h-11 w-11 items-center justify-center rounded-full bg-gold-500 text-navy-950 opacity-0 shadow-lift transition-all duration-500 group-hover:opacity-100">
          {sermon.videoUrl ? (
            <PlayIcon className="h-4.5 w-4.5 translate-x-0.5" />
          ) : (
            <MiniIcon name="note" className="h-5 w-5" />
          )}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="text-[0.68rem] font-bold uppercase tracking-[0.18em] text-gold-600">
          {formatDate(sermon.sermonDate)}
        </p>
        <h3 className="mt-2 font-display text-lg font-medium leading-snug text-navy-900 transition-colors group-hover:text-navy-700">
          {sermon.title}
        </h3>
        <p className="mt-1.5 text-sm text-ink-500">
          {sermon.speaker}
          {sermon.scripture && (
            <span className="text-ink-300"> · {sermon.scripture}</span>
          )}
        </p>
        <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-ink-500">
          {sermon.summary}
        </p>
      </div>
    </Link>
  );
}

/* ------------------------------ Event card ------------------------------ */

export function EventCard({ event, large = false }: { event: Event; large?: boolean }) {
  const d = dateParts(event.eventDate);
  return (
    <Link
      href={`/events/${event.slug}`}
      className={`group card-surface overflow-hidden transition-all duration-500 hover:-translate-y-1.5 hover:shadow-lift ${
        large ? "grid md:grid-cols-2" : "flex flex-col"
      }`}
    >
      <div className={`relative overflow-hidden ${large ? "min-h-64 md:h-full" : "aspect-[16/9]"}`}>
        <Image
          src={event.image}
          alt={`Event — ${event.title}`}
          fill
          priority={large}
          sizes={large ? "(max-width: 768px) 100vw, 50vw" : "(max-width: 768px) 100vw, 33vw"}
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/55 via-transparent to-transparent" />
        <span className="absolute left-4 top-4 rounded-full bg-navy-950/70 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.16em] text-gold-300 backdrop-blur-sm">
          {event.category}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-xl bg-navy-800 text-cream-50">
            <span className="font-display text-xl font-semibold leading-none text-gold-400">
              {d.day}
            </span>
            <span className="mt-0.5 text-[0.6rem] font-bold uppercase tracking-widest">
              {d.month}
            </span>
          </div>
          <div>
            <p className="text-[0.68rem] font-bold uppercase tracking-[0.16em] text-ink-300">
              {d.weekday}, {d.year}
            </p>
            <h3 className="mt-1 font-display text-lg font-medium leading-snug text-navy-900 group-hover:text-navy-700">
              {event.title}
            </h3>
          </div>
        </div>
        <div className="mt-4 space-y-1.5 text-sm text-ink-500">
          <p className="flex items-center gap-2">
            <MiniIcon name="calendar" className="h-4 w-4 text-gold-600" />
            {event.startTime}
            {event.endTime ? ` – ${event.endTime}` : ""}
          </p>
          <p className="flex items-center gap-2">
            <MiniIcon name="pin" className="h-4 w-4 text-gold-600" />
            {event.location}
          </p>
        </div>
        <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-ink-500">
          {event.description}
        </p>
        <span className="mt-auto inline-flex items-center gap-2 pt-4 text-sm font-bold text-gold-700">
          {event.registrationOpen ? "Register / Details" : "View Details"}
          <svg className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path d="M3 10h13m0 0-5-5m5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </div>
    </Link>
  );
}

/* ------------------------------ Ministry card ------------------------------ */

export function MinistryCard({ ministry }: { ministry: Ministry }) {
  return (
    <Link
      href={`/ministries/${ministry.slug}`}
      className="group relative block overflow-hidden rounded-2xl shadow-soft"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={ministry.image}
          alt={`${ministry.name} ministry`}
          fill
          sizes="(max-width: 768px) 100vw, 50vw"
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/35 to-navy-950/10 transition-colors duration-500 group-hover:from-navy-950/95" />
      </div>
      <div className="absolute inset-x-0 bottom-0 p-5">
        <span className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/50 bg-navy-950/60 text-gold-400 backdrop-blur-sm transition-colors duration-500 group-hover:bg-gold-500 group-hover:text-navy-950">
          <MiniIcon name={ministry.iconKey} className="h-5 w-5" />
        </span>
        <h3 className="font-display text-xl font-medium text-cream-50">
          {ministry.name}
        </h3>
        <p className="mt-1 text-sm text-cream-100/70">{ministry.tagline}</p>
        <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.18em] text-gold-400 opacity-0 transition-all duration-500 group-hover:opacity-100">
          Explore
          <svg className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path d="M3 10h13m0 0-5-5m5 5-5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </div>
    </Link>
  );
}

/* ------------------------------ Testimonial ------------------------------ */

export function TestimonialCard({
  quote,
  name,
  detail,
}: {
  quote: string;
  name: string;
  detail: string;
}) {
  return (
    <figure className="card-surface relative flex h-full flex-col p-7">
      <svg
        className="absolute -top-4 left-6 h-9 w-9 text-gold-400"
        viewBox="0 0 40 40"
        fill="currentColor"
        aria-hidden="true"
      >
        <path d="M10 24c0-6.6 3.6-12 9.4-14.6l1.2 2.2C16.4 14 14.6 17 14.2 20h4.3v12H10V24Zm14 0c0-6.6 3.6-12 9.4-14.6l1.2 2.2C30.4 14 28.6 17 28.2 20h4.3v12H24V24Z" />
      </svg>
      <blockquote className="flex-1 pt-4 font-display text-lg italic leading-relaxed text-navy-800">
        “{quote}”
      </blockquote>
      <figcaption className="mt-6 flex items-center gap-3 border-t border-navy-900/8 pt-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-navy-800 font-display text-sm font-semibold text-gold-400">
          {name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </span>
        <span>
          <span className="block text-sm font-bold text-navy-900">{name}</span>
          <span className="block text-xs text-ink-500">{detail}</span>
        </span>
      </figcaption>
    </figure>
  );
}
