import { asc } from "drizzle-orm";
import Nav from "./Nav";
import { db } from "@/db";
import { ministries as ministriesTable } from "@/db/schema";

export default async function Header() {
  const rows = await db
    .select({ name: ministriesTable.name, slug: ministriesTable.slug })
    .from(ministriesTable)
    .orderBy(asc(ministriesTable.sort));

  return (
    <header>
      <Nav
        ministries={rows.map((r) => ({
          name: r.name,
          href: `/ministries/${r.slug}`,
        }))}
      />
    </header>
  );
}
