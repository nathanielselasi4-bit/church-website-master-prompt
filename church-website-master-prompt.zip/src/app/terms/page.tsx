import type { Metadata } from "next";
import { Reveal } from "@/components/ui";

export const metadata: Metadata = {
  title: "Terms of Use",
  description:
    "Terms of use for the REDEEM Church website — content, giving, events, and acceptable use.",
};

export default function TermsPage() {
  return (
    <section className="py-20 lg:py-24">
      <div className="container-redeem max-w-3xl">
        <Reveal>
          <p className="eyebrow">
            <span className="gold-hairline" aria-hidden="true" />
            Terms of Use
          </p>
          <h1 className="mt-4 font-display text-4xl font-medium tracking-tight text-navy-900">
            Simple terms for a simple web
          </h1>
          <div className="mt-8 space-y-6 text-[0.95rem] leading-relaxed text-ink-700">
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">The site</h2>
              <p className="mt-2">
                This website is operated by REDEEM Church. By using the site
                you agree to these terms. Content is provided for the benefit
                of the community and the public, free of charge.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Content &amp; media</h2>
              <p className="mt-2">
                Sermons, videos, images and writing on this site belong to
                REDEEM Church or are used under license. You may share
                links and short quotations with attribution. Placeholders
                marked as &quot;sample&quot; on this site are not official
                church information until replaced by the church office.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Gives &amp; gifts</h2>
              <p className="mt-2">
                Online giving is processed by a third-party, PCI-compliant
                payment provider when connected. Nothing on this site
                constitutes financial advice, and gift processing is subject
                to that provider&apos;s own terms.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Events &amp; registration</h2>
              <p className="mt-2">
                Event registrations are held subject to capacity and church
                confirmation. Participation in church activities is governed
                by the conduct expectations communicated by the event team.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Acceptable use</h2>
              <p className="mt-2">
                Please do not attempt to disrupt, overload, or misuse the
                site, or submit false or harmful information through our
                forms. We reserve the right to limit access if these terms
                are breached.
              </p>
            </div>
            <p className="border-t border-navy-900/8 pt-6 text-sm text-ink-500">
              Sample terms prepared for the REDEEM website — review with the
              church (and, where appropriate, a legal advisor) before
              publication.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
