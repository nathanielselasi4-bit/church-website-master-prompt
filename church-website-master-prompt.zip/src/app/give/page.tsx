import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Reveal, SectionHeading, SampleNote, MiniIcon, GoldDivider } from "@/components/ui";
import { GiveForm } from "@/components/forms";
import { site } from "@/lib/site";
import { img } from "@/lib/images";

export const metadata: Metadata = {
  title: "Give Online — Generosity in Action at REDEEM",
  description:
    "Give to REDEEM. Your generosity helps advance the Gospel, serve people and strengthen our community — one-time or recurring, online or in person.",
};

const faqs = [
  {
    q: "Where does my giving go?",
    a: "Your gift is allocated to the fund you choose: the General Fund covers worship, teaching and church operations; Missions & Outreach funds local compassion and global partnerships; the Building Fund, Benevolence and Media Fund each serve their named purpose. We report financials to members transparently.",
  },
  {
    q: "Is my gift secure?",
    a: "Yes. No card details are entered or stored on this website. When online giving is fully connected, you will receive a secure payment link handled by a PCI-compliant payment processor. We will never ask for card numbers by email or phone.",
  },
  {
    q: "Can I give recurring gifts?",
    a: "Absolutely — monthly, quarterly or yearly. Recurring giving is the backbone that lets us plan with hope: planting ministries, supporting missionaries and serving the community consistently. You can adjust or stop at any time.",
  },
  {
    q: "Can I give in person or by other means?",
    a: `Of course. Giving baskets are available at every service, and a bank transfer option is listed below (sample details). For any method, our office can issue a receipt — just email ${site.email} (sample contact) after giving.`,
  },
];

export default function GivePage() {
  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.foodAid} alt="" fill priority sizes="100vw" className="object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/90 to-navy-950/65" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Give
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              Generosity is love{" "}
              <em className="italic text-gold-400">with its sleeves rolled up</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Your generosity helps REDEEM advance the Gospel, serve people
              and strengthen our community. Every gift — big or small, once or
              ongoing — moves the mission.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          <Reveal>
            <div className="card-surface p-6 sm:p-8">
              <h2 className="font-display text-2xl font-medium text-navy-900">
                Give online
              </h2>
              <p className="mt-2 text-sm text-ink-500">
                Choose a frequency and fund. This page records your intention
                securely — you will receive a secure payment link by email once
                online giving is connected.
              </p>
              <div className="mt-6">
                <GiveForm />
              </div>
            </div>
          </Reveal>

          <aside className="space-y-6">
            <Reveal delay={80}>
              <div className="card-surface p-6 sm:p-7" id="instructions">
                <h2 className="text-[0.68rem] font-bold uppercase tracking-[0.22em] text-gold-600">
                  Other Ways to Give
                </h2>
                <ul className="mt-5 space-y-4 text-sm text-ink-700">
                  <li className="flex items-start gap-3">
                    <MiniIcon name="hand" className="mt-0.5 h-4.5 w-4.5 shrink-0 text-gold-600" />
                    <span>
                      <strong>In person</strong> — giving baskets are
                      available at the back of the worship space at every
                      service.
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MiniIcon name="note" className="mt-0.5 h-4.5 w-4.5 shrink-0 text-gold-600" />
                    <span>
                      <strong>Bank transfer</strong> — account name: REDEEM
                      Church; account &amp; bank details provided by the church
                      office (sample — details to be confirmed).
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MiniIcon name="mail" className="mt-0.5 h-4.5 w-4.5 shrink-0 text-gold-600" />
                    <span>
                      <strong>Receipts</strong> — email{" "}
                      <a href={`mailto:${site.email}`} className="font-bold text-gold-700 hover:text-gold-600">
                        {site.email}
                      </a>{" "}
                      after giving to request a receipt.
                    </span>
                  </li>
                </ul>
              </div>
            </Reveal>
            <Reveal delay={140}>
              <div className="rounded-2xl bg-navy-900 p-6 sm:p-7">
                <GoldDivider className="max-w-24" />
                <p className="mt-5 font-display text-xl italic leading-relaxed text-cream-100/90">
                  “Each of you should give what you have decided in your heart
                  to give, not reluctantly or under compulsion, for God loves
                  a cheerful giver.”
                </p>
                <p className="mt-3 text-[0.68rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                  2 Corinthians 9:7
                </p>
                <Link href="/roadmap" className="btn-ghost-light mt-6 !px-4 !py-2.5 text-xs">
                  Where Giving Goes — Our Roadmap
                </Link>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>

      {/* FAQ */}
      <section className="border-t border-navy-900/8 bg-cream-100/60 py-20">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="Giving FAQs"
              title="Honest answers to giving questions"
              align="center"
            />
          </Reveal>
          <div className="mx-auto mt-12 max-w-3xl space-y-3">
            {faqs.map((f, i) => (
              <Reveal key={f.q} delay={i * 40}>
                <details className="group card-surface overflow-hidden open:border-gold-500/40">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 p-5 sm:p-6 [&::-webkit-details-marker]:hidden">
                    <span className="font-display text-lg font-medium text-navy-900">{f.q}</span>
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-navy-900/15 text-navy-800 transition-transform duration-300 group-open:rotate-45 group-open:border-gold-500/50 group-open:text-gold-700" aria-hidden="true">
                      <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                        <path d="M7 1v12M1 7h12" />
                      </svg>
                    </span>
                  </summary>
                  <p className="border-t border-navy-900/8 px-5 pb-6 pt-4 text-[0.95rem] leading-relaxed text-ink-700 sm:px-6">
                    {f.a}
                  </p>
                </details>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-8">
            <SampleNote>No payment providers are listed on this site because none have been contracted yet — a secure, PCI-compliant processor will be connected before launch.</SampleNote>
          </Reveal>
        </div>
      </section>
    </>
  );
}
