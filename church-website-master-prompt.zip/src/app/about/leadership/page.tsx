import type { Metadata } from "next";
import { asc } from "drizzle-orm";
import Link from "next/link";
import { Reveal, SampleNote, ArrowIcon, MiniIcon } from "@/components/ui";
import { db } from "@/db";
import { leaders } from "@/db/schema";

export const metadata: Metadata = {
  title: "Leadership — The People Behind REDEEM",
  description:
    "Meet the leadership team of REDEEM — the pastors and ministry leads shepherding our family with faith, humility and purpose.",
};

function initials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
}

export default async function LeadershipPage() {
  const team = await db.select().from(leaders).orderBy(asc(leaders.sort));

  return (
    <>
      <section className="bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Leadership
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              Servant leaders, shepherding{" "}
              <em className="italic text-gold-400">with open hands</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Our leaders are called to serve, not to be served. Meet the team
              behind REDEEM — and know you can approach any of them, at any
              time, with your questions and your heart.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-20 lg:py-24">
        <div className="container-redeem">
          {team.length === 0 ? (
            <div className="card-surface mx-auto max-w-xl p-12 text-center">
              <MiniIcon name="hand" className="mx-auto h-8 w-8 text-gold-500" />
              <p className="mt-4 font-display text-2xl text-navy-900">Leadership profiles coming soon</p>
              <p className="mt-2 text-sm text-ink-500">Our team page is being prepared. In the meantime, our office will connect you with the right person.</p>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {team.map((l, i) => (
                <Reveal key={l.id} delay={(i % 2) * 100} className="h-full">
                  <article className="card-surface flex h-full gap-5 p-6 transition-all duration-500 hover:-translate-y-1 hover:shadow-lift sm:p-7">
                    <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full border-2 border-gold-500/60 bg-navy-800 font-display text-2xl font-medium text-gold-400">
                      {initials(l.name)}
                    </div>
                    <div className="min-w-0">
                      <h2 className="font-display text-xl font-medium text-navy-900">{l.name}</h2>
                      <p className="mt-0.5 text-[0.7rem] font-bold uppercase tracking-[0.18em] text-gold-600">
                        {l.role}
                      </p>
                      <p className="mt-3 text-sm leading-relaxed text-ink-700">{l.bio}</p>
                      <p className="mt-4 flex items-start gap-2 text-xs font-semibold text-ink-500">
                        <MiniIcon name="hand" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold-600" />
                        {l.responsibility}
                      </p>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>
          )}

          <Reveal className="mt-10">
            <SampleNote>
              Leadership profiles shown are sample placeholders (monogram portraits) — replace with your actual team and photography.
            </SampleNote>
          </Reveal>

          <Reveal delay={100}>
            <div className="mt-12 flex flex-col items-center gap-4 rounded-2xl border border-gold-500/25 bg-navy-900 p-10 text-center">
              <p className="font-display text-2xl text-cream-50">
                You are also part of leadership — here, everyone serves.
              </p>
              <p className="max-w-xl text-sm text-cream-100/65">
                Whether it is a team, a gift or a season, there is a place for
                you in the life of REDEEM. Tell us where God is leading you.
              </p>
              <div className="mt-2 flex flex-wrap justify-center gap-4">
                <Link href="/volunteer" className="btn-gold">
                  Volunteer With Us
                  <ArrowIcon />
                </Link>
                <Link href="/contact" className="btn-ghost-light">
                  Contact Our Office
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
