import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Reveal, SectionHeading, GoldDivider, SampleNote, ArrowIcon, MiniIcon } from "@/components/ui";
import { img } from "@/lib/images";

export const metadata: Metadata = {
  title: "About REDEEM — Who We Are, Story, Vision & Mission",
  description:
    "Discover who REDEEM is: our story, our vision, our mission and the values — faith, hope, grace, purpose and community — that shape everything we do.",
};

const values = [
  {
    icon: "flame",
    name: "Faith",
    body: "We take the Scriptures seriously and follow Jesus wholly — in the ordinary days and the extraordinary ones.",
  },
  {
    icon: "sun",
    name: "Hope",
    body: "We carry the future with us. No matter your history, your story is not over and God is not finished with you.",
  },
  {
    icon: "hand",
    name: "Grace",
    body: "We are received by grace, so we extend grace — to ourselves, to each other, and to a world that has run out of invitations.",
  },
  {
    icon: "globe",
    name: "Purpose",
    body: "You were made for more than drifting. We help one another discover and walk in the purpose God placed inside them.",
  },
  {
    icon: "heart",
    name: "Community",
    body: "No one walks here in a solo act. We are a household — we eat together, pray together and carry one another.",
  },
];

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.pews} alt="" fill sizes="100vw" className="object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/80 to-navy-950/50" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              About REDEEM
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              We are a family of believers,{" "}
              <em className="italic text-gold-400">renewed and on a mission.</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75 sm:text-lg">
              REDEEM exists for one reason: to point people to Jesus — through
              worship that moves hearts, Scripture that holds weight, and
              community that carries you.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Who we are */}
      <section className="py-20 lg:py-28">
        <div className="container-redeem grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal>
            <SectionHeading
              eyebrow="Who We Are"
              title={<>A household, not an audience</>}
              intro="We are ordinary people gathered by extraordinary grace."
            />
            <div className="mt-6 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
              <p>
                When people first walk through our doors, we want them to feel
                two things at once: that they belong, and that God is real.
                Everything about REDEEM — from our worship to our welcome
                desks — is designed to create that experience.
              </p>
              <p>
                We are believers from every background and season of life.
                Some of us have followed Jesus for decades; some of us are
                asking questions for the first time. Both are at home here.
                That is not a compromise of the gospel — it is one of its
                greatest privileges.
              </p>
              <p>
                We measure ourselves by one question: are lives being
                transformed by Jesus, and are our neighbours seeing Him in us?
              </p>
            </div>
          </Reveal>
          <Reveal delay={140} className="relative">
            <div className="absolute -left-4 -top-4 h-full w-full rounded-2xl border border-gold-500/40" aria-hidden="true" />
            <div className="relative overflow-hidden rounded-2xl">
              <Image
                src={img.congregation}
                alt="The REDEEM congregation gathered for worship"
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* Our story */}
      <section id="story" className="scroll-mt-24 border-y border-navy-900/8 bg-cream-100/60 py-20 lg:py-24">
        <div className="container-redeem grid gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal className="order-2 relative lg:order-1">
            <div className="absolute -right-4 -bottom-4 h-full w-full rounded-2xl border border-gold-500/40" aria-hidden="true" />
            <div className="relative overflow-hidden rounded-2xl">
              <Image
                src={img.interior}
                alt="Inside the REDEEM worship space"
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
          </Reveal>
          <Reveal delay={120} className="order-1 lg:order-2">
            <SectionHeading
              eyebrow="Our Story"
              title={<>It started with a living room and a longing</>}
            />
            <div className="mt-6 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
              <p>
                REDEEM began the way many genuine things do: a small group of
                friends who were tired of going through the motions and wanted
                to actually meet God, take the Bible seriously, and love their
                city.
              </p>
              <p>
                Those gatherings grew. Questions got deeper. Prayers got real.
                People who thought they had outgrown church found themselves
                discovering it for the first time — and people who had never
                been curious found a door that was genuinely open.
              </p>
              <p>
                Today, REDEEM is a growing family with a simple heritage: we
                have always worshipped with honesty, studied the Word with
                humility, and sent our people out with purpose. The name is a
                reminder — every life here is a redeemed life.
              </p>
            </div>
            <div className="mt-6">
              <SampleNote>Our Story is sample narrative content — replace with your church&apos;s actual history.</SampleNote>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Vision & Mission */}
      <section id="vision" className="scroll-mt-24 bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="Our Vision"
              title={<>A city shaped by the love of Christ</>}
              light
              intro="We imagine a community where the gospel is not just spoken but seen — in homes, schools, workplaces and streets."
            />
          </Reveal>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            <Reveal delay={80}>
              <div className="h-full rounded-2xl border border-cream-50/10 bg-navy-900/60 p-8">
                <MiniIcon name="sun" className="h-8 w-8 text-gold-400" />
                <h3 className="mt-5 font-display text-2xl text-cream-50">Our Vision</h3>
                <p className="mt-3 text-[0.95rem] leading-relaxed text-cream-100/70">
                  A generation of believers who know Jesus deeply, love people
                  broadly, and carry His light into every room they enter —
                  until our whole city looks different because REDEEM loves it.
                </p>
              </div>
            </Reveal>
            <Reveal delay={160}>
              <div id="mission" className="h-full scroll-mt-24 rounded-2xl border border-gold-400/30 bg-navy-900/80 p-8">
                <MiniIcon name="flame" className="h-8 w-8 text-gold-400" />
                <h3 className="mt-5 font-display text-2xl text-cream-50">Our Mission</h3>
                <p className="mt-3 text-[0.95rem] leading-relaxed text-cream-100/70">
                  To make disciples of Jesus Christ who worship with all their
                  hearts, grow in the Word, live in community, and serve the
                  city and the nations — until everyone knows the name that
                  redeems.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Values */}
      <section id="values" className="scroll-mt-24 py-20 lg:py-28">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="Our Values"
              title="Five words that shape everything"
              intro="These are not slogans on a wall. They are the operating system of REDEEM — how we worship, decide, lead and love."
              align="center"
            />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {values.map((v, i) => (
              <Reveal key={v.name} delay={i * 70} className="h-full">
                <div className="group h-full rounded-2xl border border-navy-900/8 bg-white/70 p-6 text-center transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-500/40 hover:shadow-lift">
                  <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-navy-800 text-gold-400 transition-colors duration-500 group-hover:bg-gold-500 group-hover:text-navy-950">
                    <MiniIcon name={v.icon} className="h-6 w-6" />
                  </span>
                  <h3 className="mt-5 font-display text-xl font-medium text-navy-900">{v.name}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-ink-500">{v.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <GoldDivider className="mx-auto mt-14 max-w-xs" />
          <Reveal className="mt-10 text-center">
            <p className="font-display text-2xl italic text-navy-800">
              “We are where we meet — and we are who we love.”
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link href="/visit" className="btn-gold">
                Plan Your Visit
                <ArrowIcon />
              </Link>
              <Link href="/about/leadership" className="btn-outline-dark">
                Meet Our Leadership
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
