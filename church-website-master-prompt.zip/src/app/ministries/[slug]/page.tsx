import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { Reveal, MiniIcon, ArrowIcon } from "@/components/ui";
import { db } from "@/db";
import { ministries as ministriesTable } from "@/db/schema";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const row = await db.select().from(ministriesTable).where(eq(ministriesTable.slug, slug)).limit(1);
  const m = row[0];
  if (!m) return { title: "Ministry Not Found" };
  return {
    title: `${m.name} — REDEEM Ministries`,
    description: m.tagline || m.description,
    openGraph: {
      title: `${m.name} | REDEEM Ministries`,
      description: m.tagline || m.description,
      images: m.image ? [m.image] : undefined,
    },
  };
}

export default async function MinistryDetailPage({ params }: Props) {
  const { slug } = await params;
  const rows = await db.select().from(ministriesTable).where(eq(ministriesTable.slug, slug)).limit(1);
  const m = rows[0];
  if (!m) notFound();

  const activities = m.activities.split("|").map((a) => a.trim()).filter(Boolean);

  return (
    <>
      <section className="relative overflow-hidden bg-navy-950">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={m.image} alt="" fill priority sizes="100vw" className="object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/80 to-navy-950/55" />
        </div>
        <div className="container-redeem relative py-20 lg:py-24">
          <Reveal>
            <Link href="/ministries" className="group inline-flex items-center gap-2 text-sm font-bold text-gold-400 transition-colors hover:text-gold-300">
              <svg className="h-4 w-4 rotate-180 transition-transform group-hover:-translate-x-1" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <path d="M3 10h13m0 0-5-5m5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              All Ministries
            </Link>
            <span className="mt-6 inline-flex h-14 w-14 items-center justify-center rounded-full border border-gold-400/50 bg-navy-950/60 text-gold-400">
              <MiniIcon name={m.iconKey} className="h-6 w-6" />
            </span>
            <h1 className="mt-5 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              {m.name}
            </h1>
            <p className="mt-3 font-display text-xl italic text-gold-300">{m.tagline}</p>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-cream-100/75">
              {m.description}
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          <div className="space-y-10">
            <Reveal>
              <div>
                <h2 className="font-display text-2xl font-medium text-navy-900">Our Purpose</h2>
                <p className="mt-3 text-[0.975rem] leading-relaxed text-ink-700">{m.purpose}</p>
              </div>
            </Reveal>
            <Reveal delay={80}>
              <div>
                <h2 className="font-display text-2xl font-medium text-navy-900">What We Do</h2>
                <ul className="mt-5 grid gap-3 sm:grid-cols-2">
                  {activities.map((a) => (
                    <li key={a} className="card-surface flex items-start gap-3 p-4 text-sm text-ink-700">
                      <svg className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold-600" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true">
                        <path d="M5 0L10 5L5 10L0 5Z" />
                      </svg>
                      {a}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>

          <aside className="space-y-6 lg:sticky lg:top-28 lg:self-start">
            <Reveal delay={60}>
              <div className="card-surface p-6 sm:p-7">
                <h2 className="text-[0.68rem] font-bold uppercase tracking-[0.22em] text-gold-600">
                  Ministry Details
                </h2>
                <dl className="mt-4 space-y-4 text-sm">
                  <div>
                    <dt className="flex items-center gap-2 font-semibold text-ink-500">
                      <MiniIcon name="calendar" className="h-4 w-4 text-gold-600" />
                      Meeting
                    </dt>
                    <dd className="mt-1 font-semibold text-navy-900">{m.meetingInfo}</dd>
                  </div>
                  <div>
                    <dt className="flex items-center gap-2 font-semibold text-ink-500">
                      <MiniIcon name="hand" className="h-4 w-4 text-gold-600" />
                      Lead
                    </dt>
                    <dd className="mt-1 font-semibold text-navy-900">
                      {m.leaderName}
                      <span className="block text-xs font-medium text-ink-500">{m.leaderTitle}</span>
                    </dd>
                  </div>
                </dl>
                <div className="mt-6 flex flex-col gap-2.5 border-t border-navy-900/8 pt-6">
                  <Link href="/volunteer" className="btn-gold !px-4 !py-2.5 text-xs">
                    Join / Volunteer
                    <ArrowIcon />
                  </Link>
                  <Link href="/contact" className="btn-outline-dark !px-4 !py-2.5 text-xs">
                    Ask a Question
                  </Link>
                </div>
              </div>
            </Reveal>
            <Reveal delay={120}>
              <div className="rounded-2xl bg-navy-900 p-6">
                <p className="font-display text-xl text-cream-50">
                  “Each of you should use whatever gift you have received to
                  serve others.”
                </p>
                <p className="mt-3 text-[0.68rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                  1 Peter 4:10
                </p>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}
