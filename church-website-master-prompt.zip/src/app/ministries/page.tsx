import type { Metadata } from "next";
import { asc } from "drizzle-orm";
import { MinistryCard } from "@/components/cards";
import { Reveal, ArrowIcon } from "@/components/ui";
import Link from "next/link";
import { db } from "@/db";
import { ministries as ministriesTable } from "@/db/schema";

export const metadata: Metadata = {
  title: "Ministries — Grow and Serve at REDEEM",
  description:
    "Explore REDEEM's ministries: Children, Youth, Women, Men, Worship, Media, Prayer, Outreach & Missions. Find your place to grow and serve.",
};

export default async function MinistriesPage() {
  const ministries = await db
    .select()
    .from(ministriesTable)
    .orderBy(asc(ministriesTable.sort));

  return (
    <>
      <section className="bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Ministries
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              A family that grows{" "}
              <em className="italic text-gold-400">together and serves together</em>
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Eight ministries, one body. Each one exists to help you grow
              deeper and reach further — and each one needs you. Not
              professionals: participants.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem">
          {ministries.length === 0 ? (
            <Reveal>
              <div className="card-surface mx-auto max-w-xl p-12 text-center">
                <p className="font-display text-2xl text-navy-900">Ministries coming soon</p>
                <p className="mt-2 text-sm text-ink-500">We are organising our ministries. Contact us and we will point you to the right place.</p>
              </div>
            </Reveal>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {ministries.map((m, i) => (
                <Reveal key={m.slug} delay={(i % 4) * 70}>
                  <MinistryCard ministry={m} />
                </Reveal>
              ))}
            </div>
          )}

          <Reveal className="mt-14">
            <div className="flex flex-col items-center gap-4 rounded-2xl bg-gradient-to-r from-gold-500 to-gold-400 p-10 text-center">
              <h2 className="font-display text-2xl font-medium text-navy-950 sm:text-3xl">
                Not sure where you fit? Start here.
              </h2>
              <p className="max-w-xl text-sm font-medium leading-relaxed text-navy-900/80">
                Tell us a little about your gifts and availability, and our
                volunteer team will sit down with you and find your place.
              </p>
              <Link href="/volunteer" className="btn-dark mt-1">
                Volunteer With Us
                <ArrowIcon />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
