import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Fraunces, Manrope } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { MobileActionBar } from "@/components/Nav";
import { site } from "@/lib/site";
import { img } from "@/lib/images";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "REDEEM Church — A Place of Faith, Hope, Love & Purpose",
    template: "%s | REDEEM Church",
  },
  description:
    "REDEEM is a modern church community pursuing encounters with God, authentic worship, and lives of purpose. Discover our services, sermons, events and ministries — and plan your visit.",
  keywords: [
    "REDEEM Church",
    "church near me",
    "Christian church",
    "Sunday worship",
    "church services",
    "sermons",
    "prayer",
    "Christian community",
  ],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: site.url,
    siteName: "REDEEM Church",
    title: "REDEEM Church — A Place of Faith, Hope, Love & Purpose",
    description:
      "A place to encounter God. A community to discover purpose. Discover our services, sermons, events and ministries.",
    images: [
      {
        url: img.hero,
        width: 1920,
        height: 1080,
        alt: "A gathered congregation worshipping with raised hands at REDEEM",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "REDEEM Church — A Place of Faith, Hope, Love & Purpose",
    description:
      "A place to encounter God. A community to discover purpose.",
    images: [img.hero],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: "#050c17",
  width: "device-width",
  initialScale: 1,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Church",
      name: site.legalName,
      slogan: site.tagline,
      description: site.shortDescription,
      url: site.url,
      email: site.email,
      telephone: site.phone,
      address: {
        "@type": "PostalAddress",
        streetAddress: site.address.line1,
        addressLocality: site.address.city,
      },
      sameAs: site.socials.map((s) => s.href),
    },
    {
      "@type": "WebSite",
      name: site.name,
      url: site.url,
      inLanguage: "en",
      publisher: { "@type": "Church", name: site.legalName },
    },
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${manrope.variable}`}>
      <body>
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-gold-500 focus:px-5 focus:py-2.5 focus:text-sm focus:font-bold focus:text-navy-950"
        >
          Skip to main content
        </a>
        <Header />
        <main id="main" className="pb-16 md:pb-0">
          {children}
        </main>
        <Footer />
        <MobileActionBar />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}
