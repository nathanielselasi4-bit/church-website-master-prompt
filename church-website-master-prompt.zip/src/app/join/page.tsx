import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Reveal, SectionHeading, SampleNote, ArrowIcon, MiniIcon } from "@/components/ui";
import { NewsletterForm } from "@/components/forms";
import { img } from "@/lib/images";

export const metadata: Metadata = {
  title: "Join REDEEM — Become Part of the Family",
  description:
    "Ready to make REDEEM your church? Discover how to join, find a small group, and take your next step — from first visit to deep belonging.",
};

const steps = [
  {
    n: "01",
    title: "Visit us",
    body: "Come to a Sunday service — that is genuinely the first step. Plan your visit and tell us you are coming so we can welcome you properly.",
    cta: { label: "Plan Your Visit", href: "/visit" },
  },
  {
    n: "02",
    title: "Connect",
    body: "Meet a small group or ministry team. This is where names replace strangers and your gifts start to find their place.",
    cta: { label: "Explore Ministries", href: "/ministries" },
  },
  {
    n: "03",
    title: "Belong & serve",
    body: "Commit, give, serve and grow. Belonging here is not an audience pass — it is a family invitation with work and worship in equal measure.",
    cta: { label: "Volunteer", href: "/volunteer" },
  },
];

const groups = [
  { name: "Riverside", day: "Tuesdays, 07:00 PM", place: "Member's home (sample)", focus: "Study: Gospel of John" },
  { name: "New Beginnings", day: "Thursdays, 10:00 AM", place: "REDEEM Community Room (sample)", focus: "First steps in faith" },
  { name: "Kikoy Circle", day: "Sundays, 12:30 PM", place: "REDEEM Cafe (sample)", focus: "Life groups & discipleship" },
];

export default function JoinPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.friends} alt="" fill priority sizes="100vw" className="object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/60" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Join REDEEM
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              Church is not a place you attend.{" "}
              <em className="italic text-gold-400">It is a family you join.</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Making REDEEM your church is not a membership form — it is a
              relationship. Here is the honest path from first visit to
              belonging.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/visit" className="btn-gold">
                Start With a Visit
                <ArrowIcon />
              </Link>
              <Link href="/contact" className="btn-ghost-light">
                Talk to Our Team
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Steps */}
      <section className="py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="The Path"
              title="Three steps into the family"
              align="center"
            />
          </Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {steps.map((s, i) => (
              <Reveal key={s.n} delay={i * 90} className="h-full">
                <div className="relative h-full rounded-2xl border border-navy-900/8 bg-white/70 p-7 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/40 hover:shadow-lift">
                  <p className="font-display text-5xl font-semibold text-gold-500/50">{s.n}</p>
                  <h2 className="mt-4 font-display text-2xl font-medium text-navy-900">{s.title}</h2>
                  <p className="mt-3 text-sm leading-relaxed text-ink-500">{s.body}</p>
                  <Link href={s.cta.href} className="group mt-5 inline-flex items-center gap-2 text-sm font-bold text-gold-700">
                    {s.cta.label}
                    <ArrowIcon />
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Small groups */}
      <section className="border-y border-navy-900/8 bg-cream-100/60 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
              <div className="max-w-xl">
                <SectionHeading
                  eyebrow="Small Groups"
                  title="Where belonging actually happens"
                  intro="A dozen chairs, a Bible, some tea. Our small groups meet weekly across the city — this sample directory shows the shape of the offer."
                />
              </div>
              <Link href="/contact" className="btn-outline-dark shrink-0">
                Get Matched With a Group
              </Link>
            </div>
          </Reveal>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {groups.map((g, i) => (
              <Reveal key={g.name} delay={i * 80} className="h-full">
                <div className="card-surface h-full p-6">
                  <h3 className="font-display text-xl font-medium text-navy-900">{g.name}</h3>
                  <ul className="mt-4 space-y-2 text-sm text-ink-500">
                    <li className="flex items-center gap-2.5">
                      <MiniIcon name="calendar" className="h-4 w-4 text-gold-600" />
                      {g.day}
                    </li>
                    <li className="flex items-center gap-2.5">
                      <MiniIcon name="pin" className="h-4 w-4 text-gold-600" />
                      {g.place}
                    </li>
                    <li className="flex items-center gap-2.5">
                      <MiniIcon name="note" className="h-4 w-4 text-gold-600" />
                      {g.focus}
                    </li>
                  </ul>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-6">
            <SampleNote>Small group details are sample placeholders — replace with your actual groups and venues.</SampleNote>
          </Reveal>
        </div>
      </section>

      {/* Decision / next step */}
      <section className="py-20 lg:py-24">
        <div className="container-redeem grid items-center gap-12 lg:grid-cols-2">
          <Reveal className="relative">
            <div className="absolute -left-4 -top-4 h-full w-full rounded-2xl border border-gold-500/40" aria-hidden="true" />
            <div className="relative overflow-hidden rounded-2xl">
              <Image
                src={img.selfieGroup}
                alt="Young adults at REDEEM laughing together after a small group"
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
          </Reveal>
          <Reveal delay={120}>
            <SectionHeading
              eyebrow="The Next Step"
              title={<>Ready to go deeper?</>}
              intro="If you have trusted Jesus as your Saviour and want to make REDEEM your church, we would love to know. If you are still exploring, we would love that too — no decision is required today."
            />
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/contact" className="btn-gold">
                I&apos;m Ready — Contact Us
                <ArrowIcon />
              </Link>
              <Link href="/prayer" className="btn-outline-dark">
                Submit a Prayer Request
              </Link>
            </div>
            <div className="card-surface mt-10 p-6">
              <h3 className="text-[0.68rem] font-bold uppercase tracking-[0.22em] text-gold-600">
                Or just stay in touch
              </h3>
              <div className="mt-4">
                <NewsletterForm />
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
