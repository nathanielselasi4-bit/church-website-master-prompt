import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { count, gte, sql } from "drizzle-orm";
import { Reveal, MiniIcon, GoldDivider } from "@/components/ui";
import { PrayerForm } from "@/components/forms";
import { db } from "@/db";
import { prayerRequests } from "@/db/schema";
import { img } from "@/lib/images";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Prayer Request — We Will Pray With You",
  description:
    "Your prayer matters. Submit a confidential prayer request to the REDEEM prayer team and we will stand with you — in person, in prayer and in the Word.",
};

export default async function PrayerPage() {
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [[total], [month]] = await Promise.all([
    db.select({ n: count() }).from(prayerRequests),
    db
      .select({ n: count() })
      .from(prayerRequests)
      .where(gte(prayerRequests.createdAt, monthStart)),
  ]);

  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.prayCloth} alt="" fill priority sizes="100vw" className="object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/60" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Prayer Request
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              Your prayer matters.{" "}
              <em className="italic text-gold-400">We will stand with you.</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Our prayer team is ready — whether you are facing a diagnosis,
              a decision, a season of doubt, or a joy that overflows. Share it
              here and it will be lifted in confidential, consistent prayer.
            </p>
            {month && month.n > 0 && (
              <p className="mt-6 inline-flex items-center gap-2.5 rounded-full border border-gold-400/30 bg-navy-900/60 px-4 py-2 text-sm text-cream-100/80">
                <MiniIcon name="candle" className="h-4 w-4 text-gold-400" />
                This month, {month.n} prayer{month.n === 1 ? "" : "s"} have been carried by our team — in confidence.
              </p>
            )}
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem grid gap-10 lg:grid-cols-[1.5fr_1fr]">
          <Reveal>
            <div className="card-surface p-6 sm:p-8">
              <h2 className="font-display text-2xl font-medium text-navy-900">
                Share what is on your heart
              </h2>
              <p className="mt-2 text-sm text-ink-500">
                Fields marked optional can be skipped. Requests can be
                submitted anonymously.
              </p>
              <div className="mt-6">
                <PrayerForm />
              </div>
            </div>
          </Reveal>

          <aside className="space-y-6 lg:sticky lg:top-28 lg:self-start">
            <Reveal delay={80}>
              <div className="card-surface p-6 sm:p-7">
                <h2 className="text-[0.68rem] font-bold uppercase tracking-[0.22em] text-gold-600">
                  How We Handle Your Prayer
                </h2>
                <ul className="mt-5 space-y-4 text-sm text-ink-700">
                  {[
                    "Confidential by default. Your request is never shared publicly unless you explicitly consent.",
                    "Received by our prayer team, who will pray with and for you — and reach out if you ask them to.",
                    "Carried in corporate prayer every Friday, whether or not you ever return to this page.",
                    "You can always withdraw a request any time by contacting our office.",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-3">
                      <svg className="mt-0.5 h-4 w-4 shrink-0 text-gold-600" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true">
                        <path d="M5 0L10 5L5 10L0 5Z" />
                      </svg>
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
            <Reveal delay={140}>
              <div className="rounded-2xl bg-navy-900 p-6 sm:p-7">
                <GoldDivider className="max-w-24" />
                <p className="mt-5 font-display text-xl italic leading-relaxed text-cream-100/90">
                  “The effect of righteous prayer is powerful and full of
                  purpose.”
                </p>
                <p className="mt-3 text-[0.68rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                  James 5:16
                </p>
                <Link
                  href="/ministries/prayer-ministry"
                  className="btn-ghost-light mt-6 !px-4 !py-2.5 text-xs"
                >
                  Meet the Prayer Team
                </Link>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}
