import type { Metadata } from "next";
import Link from "next/link";
import { Reveal, SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Site Roadmap — RICE Prioritization & Future Plan",
  description:
    "How the REDEEM website is prioritized using the RICE framework (Reach, Impact, Confidence, Effort) — what shipped at launch, what comes next, and the long-term vision.",
};

type Row = {
  feature: string;
  reach: number;
  impact: number;
  confidence: number;
  effort: number;
  score: number;
  status: "shipped" | "next" | "future";
};

const rows: Row[] = [
  { feature: "Services & gathering information", reach: 10, impact: 3, confidence: 1, effort: 1, score: 30, status: "shipped" },
  { feature: "Contact & office communication", reach: 8, impact: 2, confidence: 1, effort: 1, score: 16, status: "shipped" },
  { feature: "Mobile-first responsive experience", reach: 10, impact: 3, confidence: 1, effort: 2, score: 15, status: "shipped" },
  { feature: "Plan Your Visit journey", reach: 10, impact: 3, confidence: 1, effort: 2, score: 15, status: "shipped" },
  { feature: "Prayer requests (private & consent-based)", reach: 8, impact: 3, confidence: 1, effort: 2, score: 12, status: "shipped" },
  { feature: "SEO, metadata, sitemap & performance", reach: 10, impact: 2, confidence: 1, effort: 2, score: 10, status: "shipped" },
  { feature: "Sermon library with search & filters", reach: 9, impact: 3, confidence: 0.9, effort: 3, score: 8.1, status: "shipped" },
  { feature: "Newsletter & weekly updates", reach: 8, impact: 1, confidence: 1, effort: 1, score: 8, status: "shipped" },
  { feature: "Ministry directory with detail pages", reach: 7, impact: 2, confidence: 1, effort: 2, score: 7, status: "shipped" },
  { feature: "Testimonies & community storytelling", reach: 5, impact: 1, confidence: 1, effort: 1, score: 5, status: "shipped" },
  { feature: "Online giving (secure processor integration)", reach: 6, impact: 2, confidence: 0.8, effort: 2, score: 4.8, status: "next" },
  { feature: "Event registration & confirmations", reach: 7, impact: 2, confidence: 0.9, effort: 3, score: 4.2, status: "next" },
  { feature: "Volunteer management & scheduling", reach: 5, impact: 2, confidence: 0.9, effort: 3, score: 3, status: "next" },
  { feature: "Member portal & accounts", reach: 6, impact: 3, confidence: 0.5, effort: 8, score: 1.1, status: "future" },
  { feature: "Attendance & children's check-in system", reach: 5, impact: 2, confidence: 0.5, effort: 6, score: 0.8, status: "future" },
  { feature: "Mobile app with push notifications", reach: 6, impact: 2, confidence: 0.4, effort: 8, score: 0.6, status: "future" },
];

const statusStyle: Record<Row["status"], string> = {
  shipped: "bg-gold-100 text-gold-700 border-gold-500/40",
  next: "bg-navy-50 text-navy-700 border-navy-300/40",
  future: "bg-cream-100 text-ink-500 border-navy-900/10",
};

const statusLabel: Record<Row["status"], string> = {
  shipped: "Shipped · v1",
  next: "Next · v1.5",
  future: "Future · v2+",
};

export default function RoadmapPage() {
  return (
    <>
      <section className="bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Site Roadmap
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              Built in order of <em className="italic text-gold-400">value</em>, not novelty
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Every feature on this site was ranked with the RICE framework —
              Reach × Impact × Confidence ÷ Effort. The highest-scoring
              journeys shipped first so that visitors can worship, visit, pray,
              give and serve on day one.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem">
          <Reveal>
            <div className="card-surface overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-sm">
                <caption className="sr-only">
                  RICE prioritization matrix for REDEEM website features
                </caption>
                <thead>
                  <tr className="border-b border-navy-900/10 text-[0.65rem] uppercase tracking-[0.18em] text-ink-500">
                    <th scope="col" className="px-5 py-4">Feature</th>
                    <th scope="col" className="px-3 py-4 text-center">Reach</th>
                    <th scope="col" className="px-3 py-4 text-center">Impact</th>
                    <th scope="col" className="px-3 py-4 text-center">Confidence</th>
                    <th scope="col" className="px-3 py-4 text-center">Effort</th>
                    <th scope="col" className="px-3 py-4 text-center">RICE Score</th>
                    <th scope="col" className="px-5 py-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.feature} className="border-b border-navy-900/6 last:border-0 hover:bg-cream-100/50">
                      <td className="px-5 py-3.5 font-semibold text-navy-900">{r.feature}</td>
                      <td className="px-3 py-3.5 text-center text-ink-500">{r.reach}</td>
                      <td className="px-3 py-3.5 text-center text-ink-500">{r.impact}</td>
                      <td className="px-3 py-3.5 text-center text-ink-500">{r.confidence}</td>
                      <td className="px-3 py-3.5 text-center text-ink-500">{r.effort}</td>
                      <td className="px-3 py-3.5 text-center font-display text-base font-semibold text-gold-700">
                        {r.score.toFixed(1)}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className={`inline-block rounded-full border px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] ${statusStyle[r.status]}`}>
                          {statusLabel[r.status]}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-4 text-xs text-ink-300">
              Scoring guide — Reach: share of visitors who benefit (1–10). Impact: strength of contribution to the church&apos;s mission (3 = high, 2 = medium, 1 = low). Confidence: certainty of the estimate (0–1). Effort: person-weeks of design + build (1–10).
            </p>
          </Reveal>

          <div className="mt-16 grid gap-6 lg:grid-cols-3">
            <Reveal className="h-full">
              <div className="card-surface h-full p-7">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.22em] text-gold-600">v1 — Launched</p>
                <h2 className="mt-3 font-display text-xl font-medium text-navy-900">The digital front door</h2>
                <p className="mt-3 text-sm leading-relaxed text-ink-500">
                  Homepage, About &amp; leadership, services, sermon library,
                  events, ministries, plan-your-visit, prayer, contact, giving
                  intents, newsletter, SEO and accessibility — everything a
                  first-time visitor or member needs on day one.
                </p>
              </div>
            </Reveal>
            <Reveal delay={90} className="h-full">
              <div className="card-surface h-full border-gold-500/40 p-7">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.22em] text-gold-600">v1.5 — Next</p>
                <h2 className="mt-3 font-display text-xl font-medium text-navy-900">Deeper connection</h2>
                <p className="mt-3 text-sm leading-relaxed text-ink-500">
                  Secure payment processor for online giving, event
                  confirmation emails, volunteer scheduling, children&apos;s
                  registration, and a lightweight content dashboard for the
                  church team.
                </p>
              </div>
            </Reveal>
            <Reveal delay={180} className="h-full">
              <div className="h-full rounded-2xl bg-navy-900 p-7">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.22em] text-gold-400">v2+ — Vision</p>
                <h2 className="mt-3 font-display text-xl font-medium text-cream-50">The whole ecosystem</h2>
                <p className="mt-3 text-sm leading-relaxed text-cream-100/65">
                  Member portal with accounts, church management, attendance
                  &amp; check-in, small-group management, member directory,
                  announcements and notifications, and a mobile application.
                </p>
              </div>
            </Reveal>
          </div>

          <Reveal className="mt-14 text-center">
            <h2 className="font-display text-2xl font-medium text-navy-900">
              Have a feature in mind?
            </h2>
            <p className="mx-auto mt-2 max-w-lg text-sm text-ink-500">
              We build in order of value. Tell us what would serve the church
              best and we will weigh it with the team.
            </p>
            <Link href="/contact" className="btn-dark mt-6">
              Share Your Idea
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
