import type { Metadata } from "next";
import { Reveal, SampleNote, MiniIcon } from "@/components/ui";
import { ContactForm } from "@/components/forms";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact Us — REDEEM Church Office",
  description:
    "Get in touch with the REDEEM church office. Questions about services, visiting, volunteering, media or pastoral support — we respond within two business days.",
};

export default function ContactPage() {
  return (
    <>
      <section className="bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Contact Us
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              We would rather you asked{" "}
              <em className="italic text-gold-400">than wondered</em>
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Questions about visiting, giving, ministries or your own
              journey — send them our way. Our office team responds within two
              business days.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem grid gap-10 lg:grid-cols-[1fr_1.4fr]">
          <div className="space-y-5">
            {[
              {
                icon: "pin",
                title: "Visit",
                lines: [site.address.line1, site.address.city, "Sample address — confirm with our office"],
                href: site.directionsUrl,
                link: "Get Directions",
              },
              {
                icon: "phone",
                title: "Call",
                lines: [site.phone, "Sample number — replace with the official church line", "Office hours: Mon–Fri, 09:00–16:00 (sample)"],
              },
              {
                icon: "mail",
                title: "Email",
                lines: [site.email, "Sample contact — replace with the official inbox"],
                href: `mailto:${site.email}`,
                link: "Write to Us",
              },
            ].map((c, i) => (
              <Reveal key={c.title} delay={i * 80}>
                <div className="card-surface flex items-start gap-4 p-6">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-navy-800 text-gold-400">
                    <MiniIcon name={c.icon} className="h-5 w-5" />
                  </span>
                  <div>
                    <h2 className="font-display text-lg font-medium text-navy-900">{c.title}</h2>
                    {c.lines.map((l, j) => (
                      <p key={l} className={`text-sm ${j === 0 ? "mt-1 font-semibold text-ink-700" : "mt-0.5 text-ink-500"}`}>
                        {l}
                      </p>
                    ))}
                    {c.href && (
                      <a
                        href={c.href}
                        target={c.href.startsWith("http") ? "_blank" : undefined}
                        rel={c.href.startsWith("http") ? "noopener noreferrer" : undefined}
                        className="mt-2 inline-block text-sm font-bold text-gold-700 hover:text-gold-600"
                      >
                        {c.link} →
                      </a>
                    )}
                  </div>
                </div>
              </Reveal>
            ))}
            <Reveal delay={240}>
              <div className="rounded-2xl bg-navy-900 p-6">
                <h2 className="font-display text-lg text-cream-50">Need pastoral support?</h2>
                <p className="mt-2 text-sm leading-relaxed text-cream-100/65">
                  For counselling, crisis support or prayer, please reach out
                  through the form and select “Pastoral support” — your
                  message goes directly to a pastor, not the general queue.
                </p>
              </div>
            </Reveal>
          </div>

          <Reveal delay={100}>
            <div className="card-surface p-6 sm:p-8">
              <h2 className="font-display text-2xl font-medium text-navy-900">Send us a message</h2>
              <p className="mt-2 text-sm text-ink-500">
                We read everything. Nothing you share here is published or
                shared outside the church office.
              </p>
              <div className="mt-6">
                <ContactForm />
              </div>
              <div className="mt-6">
                <SampleNote>Contact details above are sample placeholders until the church supplies official information.</SampleNote>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
