import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  contactMessages,
  eventRegistrations,
  givingIntents,
  newsletterSubscribers,
  prayerRequests,
  volunteers,
} from "@/db/schema";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

type Kind =
  | "prayer"
  | "contact"
  | "newsletter"
  | "registration"
  | "give"
  | "volunteer";

function str(v: unknown, max = 500): string {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

async function handle(
  kind: Kind,
  p: Record<string, unknown>,
): Promise<{ ok: boolean; error?: string }> {
  const name = str(p.name, 120);
  const email = str(p.email, 160).toLowerCase();
  const phone = str(p.phone, 40);

  switch (kind) {
    case "prayer": {
      const message = str(p.message, 4000);
      if (!message || !email || !EMAIL_RE.test(email)) {
        return { ok: false, error: "Please provide a valid email and your prayer request." };
      }
      await db.insert(prayerRequests).values({
        name: p.anonymous ? "Anonymous" : name || "Anonymous",
        email,
        phone: phone || null,
        category: str(p.category, 60) || "General",
        message,
        anonymous: Boolean(p.anonymous),
        consent: Boolean(p.consent),
      });
      return { ok: true };
    }

    case "contact": {
      const message = str(p.message, 4000);
      if (!name || !email || !EMAIL_RE.test(email) || !message) {
        return { ok: false, error: "Please complete all required fields." };
      }
      await db.insert(contactMessages).values({
        name,
        email,
        phone: phone || null,
        subject: str(p.subject, 80) || "General enquiry",
        message,
      });
      return { ok: true };
    }

    case "newsletter": {
      if (!email || !EMAIL_RE.test(email)) {
        return { ok: false, error: "Please provide a valid email address." };
      }
      await db
        .insert(newsletterSubscribers)
        .values({ email, source: str(p.source, 40) || "footer" })
        .onConflictDoNothing({ target: newsletterSubscribers.email });
      return { ok: true };
    }

    case "registration": {
      if (!name || !email || !EMAIL_RE.test(email)) {
        return { ok: false, error: "Please provide your name and a valid email." };
      }
      const eventId = Number(p.eventId);
      if (!Number.isInteger(eventId) || eventId <= 0) {
        return { ok: false, error: "Unknown event." };
      }
      await db.insert(eventRegistrations).values({
        eventId,
        name,
        email,
        phone: phone || null,
        attendees: Math.min(Math.max(Number(p.attendees) || 1, 1), 30),
        notes: str(p.notes, 1000),
      });
      return { ok: true };
    }

    case "give": {
      if (!name || !email || !EMAIL_RE.test(email)) {
        return { ok: false, error: "Please provide your name and a valid email." };
      }
      const amount = Math.min(Math.max(Number(p.amount) || 0, 0), 1_000_000);
      await db.insert(givingIntents).values({
        name,
        email,
        amount: amount > 0 ? amount.toFixed(2) : null,
        frequency: ["one-time", "monthly", "quarterly", "yearly"].includes(str(p.frequency, 20))
          ? str(p.frequency, 20)
          : "one-time",
        fund: str(p.fund, 80) || "General Fund",
        note: str(p.note, 400),
      });
      return { ok: true };
    }

    case "volunteer": {
      if (!name || !email || !EMAIL_RE.test(email)) {
        return { ok: false, error: "Please provide your name and a valid email." };
      }
      await db.insert(volunteers).values({
        name,
        email,
        phone: phone || null,
        ministry: str(p.ministry, 80) || "General",
        availability: str(p.availability, 80),
        motivation: str(p.motivation, 1500),
      });
      return { ok: true };
    }

    default:
      return { ok: false, error: "Unknown form type." };
  }
}

export async function POST(req: Request) {
  let body: {
    kind?: string;
    payload?: Record<string, unknown>;
    company?: string;
    eventId?: unknown;
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }

  // Honeypot: silently accept bots so they think it worked.
  if (body.company) return NextResponse.json({ ok: true });

  const kind = body.kind as Kind;
  const payload = { ...(body.payload ?? {}), eventId: body.eventId };

  try {
    const result = await handle(kind, payload);
    return NextResponse.json(result, { status: result.ok ? 200 : 422 });
  } catch (err) {
    console.error(`[forms] ${kind} failed`, err);
    return NextResponse.json({ ok: false, error: "Server error." }, { status: 500 });
  }
}
