import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Reveal, SectionHeading, SampleNote, ArrowIcon, MiniIcon } from "@/components/ui";
import { site } from "@/lib/site";
import { img } from "@/lib/images";

export const metadata: Metadata = {
  title: "Plan Your Visit — First Time at REDEEM?",
  description:
    "First time at REDEEM? Here is everything to know: where we meet, when to arrive, what to wear, what happens during the service, children's ministry, parking and who to contact.",
};

const faqs = [
  {
    q: "Where are we?",
    a: `${site.address.line1}, ${site.address.city}. (This is a sample address — confirm the official location with our office before travelling.) Use the Get Directions button and we will meet you at the door.`,
  },
  {
    q: "When should I arrive?",
    a: "Doors open 20 minutes before each service. Arriving a little early means you can grab a seat, say hello to the welcome team, and drop your children into children's ministry without rushing. Sample service times: Sunday 08:00 AM & 10:00 AM — please confirm with the church.",
  },
  {
    q: "What should I wear?",
    a: "Come as you are — that is not a phrase we use lightly. Some people will wear a suit, others trainers. The only dress code is that everyone is welcome.",
  },
  {
    q: "What happens during the service?",
    a: "Roughly 75–90 minutes: expressive worship with our live team, a clear message from the Scriptures, and a time of prayer. There is no performance pressure — sitting, standing, singing or resting are all perfectly fine. First-timers receive a simple service guide at the door.",
  },
  {
    q: "Is there a children's ministry?",
    a: `Yes — from birth to grade 6. Trained, vetted teams and secure check-in run during both Sunday services. Tell the team at the door it's your first visit and your child's leader will be briefed beforehand. Learn more on the ${"Children's Ministry"} page.`,
  },
  {
    q: "Where can I park?",
    a: `There is parking on the church grounds (sample — final parking details will be confirmed with the official address). If you use ride-hailing services, our welcome desk will be at the main entrance.`,
  },
  {
    q: "Who can I contact before I visit?",
    a: `Our team loves questions. Email ${site.email} (sample contact) or call ${site.phone} (sample line), or use the contact page. If you tell us you are visiting, a member of the hospitality team will be waiting to welcome you personally.`,
  },
  {
    q: "What should I expect spiritually?",
    a: "We worship God seriously and love people personally. Expect to feel welcome before you ever feel like you belong — because at REDEEM, being welcome is step one, not the whole journey. And if you are new to faith entirely, that is exactly where most of our stories began.",
  },
];

export default function VisitPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.fountainFriends} alt="" fill priority sizes="100vw" className="object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/60" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Plan Your Visit
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              Your first Sunday at REDEEM,{" "}
              <em className="italic text-gold-400">the honest guide</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Nerves are normal — everyone starts here. We have answered the
              questions first-timers actually ask, so the only new thing you
              have to face on Sunday is God.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href={site.directionsUrl} target="_blank" rel="noopener noreferrer" className="btn-gold">
                <MiniIcon name="pin" className="h-4 w-4" />
                Get Directions
              </a>
              <Link href="/contact" className="btn-ghost-light">
                Contact Us
                <ArrowIcon />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* At a glance */}
      <section className="relative z-10 -mt-10 pb-4">
        <div className="container-redeem grid gap-4 sm:grid-cols-3">
          {[
            { icon: "calendar", title: "Sundays", body: "08:00 AM & 10:00 AM — sample times, confirm with us" },
            { icon: "pin", title: "Location", body: `${site.address.line1}, ${site.address.city} (sample)` },
            { icon: "heart", title: "Our Promise", body: "You will be greeted by name and followed up on next week" },
          ].map((c, i) => (
            <Reveal key={c.title} delay={i * 80} className="h-full">
              <div className="card-surface h-full p-6">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-navy-800 text-gold-400">
                  <MiniIcon name={c.icon} className="h-5 w-5" />
                </span>
                <h2 className="mt-4 font-display text-lg font-medium text-navy-900">{c.title}</h2>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-500">{c.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="Your Questions, Answered"
              title="Everything first-timers ask"
              intro="If your question is not here, we would rather you asked than wondered."
              align="center"
            />
          </Reveal>
          <div className="mx-auto mt-12 max-w-3xl space-y-3">
            {faqs.map((f, i) => (
              <Reveal key={f.q} delay={i * 40}>
                <details className="group card-surface overflow-hidden open:border-gold-500/40">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 p-5 sm:p-6 [&::-webkit-details-marker]:hidden">
                    <span className="font-display text-lg font-medium text-navy-900">{f.q}</span>
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-navy-900/15 text-navy-800 transition-transform duration-300 group-open:rotate-45 group-open:border-gold-500/50 group-open:text-gold-700" aria-hidden="true">
                      <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                        <path d="M7 1v12M1 7h12" />
                      </svg>
                    </span>
                  </summary>
                  <p className="border-t border-navy-900/8 px-5 pb-6 pt-4 text-[0.95rem] leading-relaxed text-ink-700 sm:px-6">
                    {f.a}
                  </p>
                </details>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-8">
            <SampleNote>Address, phone, email and service times on this page are clearly-marked sample placeholders.</SampleNote>
          </Reveal>
        </div>
      </section>

      {/* CTA band */}
      <section className="bg-navy-900 py-16">
        <div className="container-redeem flex flex-col items-center gap-6 text-center">
          <Reveal>
            <h2 className="max-w-2xl font-display text-3xl font-medium leading-[1.15] text-cream-50 sm:text-4xl">
              Ready when you are. We will be waiting.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-cream-100/65">
              Join the First-Timers Breakfast before service, or simply walk
              through the doors on Sunday. Either way, you will not be a
              stranger for long.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link href="/events/first-timers-breakfast" className="btn-gold">
                Join First-Timers Breakfast
                <ArrowIcon />
              </Link>
              <Link href="/sermons" className="btn-ghost-light">
                Watch a Sermon First
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
