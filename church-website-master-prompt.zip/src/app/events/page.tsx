import type { Metadata } from "next";
import Link from "next/link";
import { asc, gte, sql } from "drizzle-orm";
import { EventCard } from "@/components/cards";
import { Reveal, MiniIcon, SampleNote } from "@/components/ui";
import { db } from "@/db";
import { events as eventsTable } from "@/db/schema";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Events — Conferences, Prayer, Youth & Outreach",
  description:
    "See what's happening at REDEEM: upcoming conferences, prayer meetings, youth events and community outreach. Register in one click.",
};

export default async function EventsPage() {
  const today = new Date().toISOString().slice(0, 10);
  const [upcoming, past] = await Promise.all([
    db
      .select()
      .from(eventsTable)
      .where(sql`${eventsTable.eventDate} >= ${today}`)
      .orderBy(asc(eventsTable.eventDate)),
    db
      .select()
      .from(eventsTable)
      .where(sql`${eventsTable.eventDate} < ${today}`)
      .orderBy(sql`${eventsTable.eventDate} desc`),
  ]);

  return (
    <>
      <section className="bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Events
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              There is always <em className="italic text-gold-400">something happening</em> at REDEEM
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-cream-100/75">
              From a day of deep worship to a food drive on our street corner —
              our calendar is where faith meets action. Register for anything
              that calls you.
            </p>
          </Reveal>
          <Reveal delay={100}>
            <div className="mt-8 flex flex-wrap gap-x-8 gap-y-3 border-t border-cream-50/10 pt-6">
              {[
                ["Conferences", "forward-conference"],
                ["Prayer Meetings", "prayer-and-word-night"],
                ["Youth Events", "youth-night-fire-and-freedom"],
                ["Community Events", "community-food-drive"],
              ].map(([label, slug]) => (
                <Link
                  key={slug}
                  href={`/events/${slug}`}
                  className="inline-flex items-center gap-2 text-sm font-semibold text-cream-100/70 transition-colors hover:text-gold-300"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-gold-500" aria-hidden="true" />
                  {label}
                </Link>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem">
          <Reveal>
            <h2 className="font-display text-2xl font-medium text-navy-900 sm:text-3xl">
              Upcoming Events
            </h2>
          </Reveal>
          {upcoming.length === 0 ? (
            <Reveal className="mt-8">
              <div className="card-surface mx-auto max-w-xl p-12 text-center">
                <MiniIcon name="calendar" className="mx-auto h-8 w-8 text-gold-500" />
                <p className="mt-4 font-display text-2xl text-navy-900">No upcoming events yet</p>
                <p className="mt-2 text-sm text-ink-500">
                  New events are announced here first. Subscribe in the footer
                  and you will never miss one.
                </p>
                <Link href="/contact" className="btn-dark mt-6">
                  Ask About Upcoming Events
                </Link>
              </div>
            </Reveal>
          ) : (
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              {upcoming.map((e, i) => (
                <Reveal key={e.id} delay={(i % 2) * 80} className={e.featured ? "md:col-span-2" : ""}>
                  <EventCard event={e} large={e.featured} />
                </Reveal>
              ))}
            </div>
          )}

          <Reveal className="mt-10">
            <SampleNote>Event locations shown are sample placeholders — replace with your official venue details.</SampleNote>
          </Reveal>

          {past.length > 0 && (
            <Reveal className="mt-16">
              <h2 className="font-display text-2xl font-medium text-navy-900 sm:text-3xl">
                Recently
              </h2>
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {past.slice(0, 3).map((e) => (
                  <Link
                    key={e.id}
                    href={`/events/${e.slug}`}
                    className="card-surface flex items-center gap-4 p-4 transition-all duration-500 hover:-translate-y-0.5 hover:border-gold-500/40"
                  >
                    <div className="relative h-16 w-24 shrink-0 overflow-hidden rounded-lg opacity-70">
                      <img
                        src={e.image}
                        alt=""
                        loading="lazy"
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="truncate font-display text-base text-navy-900">{e.title}</p>
                      <p className="mt-0.5 text-xs text-ink-500">{e.category} · past event</p>
                    </div>
                  </Link>
                ))}
              </div>
            </Reveal>
          )}
        </div>
      </section>
    </>
  );
}
