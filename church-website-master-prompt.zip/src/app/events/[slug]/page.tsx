import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { RegisterForm } from "@/components/forms";
import { Reveal, SampleNote, ArrowIcon, MiniIcon } from "@/components/ui";
import { dateParts } from "@/lib/format";
import { db } from "@/db";
import { events as eventsTable } from "@/db/schema";
import { site } from "@/lib/site";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const row = await db.select().from(eventsTable).where(eq(eventsTable.slug, slug)).limit(1);
  const e = row[0];
  if (!e) return { title: "Event Not Found" };
  return {
    title: e.title,
    description: e.description,
    openGraph: {
      title: `${e.title} | REDEEM Events`,
      description: e.description,
      images: e.image ? [e.image] : undefined,
    },
  };
}

export default async function EventDetailPage({ params }: Props) {
  const { slug } = await params;
  const rows = await db.select().from(eventsTable).where(eq(eventsTable.slug, slug)).limit(1);
  const e = rows[0];
  if (!e) notFound();

  const d = dateParts(e.eventDate);
  const activities = e.details.split("|").map((x) => x.trim()).filter(Boolean);

  return (
    <>
      <section className="relative overflow-hidden bg-navy-950">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={e.image} alt="" fill priority sizes="100vw" className="object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/75 to-navy-950/50" />
        </div>
        <div className="container-redeem relative py-20 lg:py-24">
          <Reveal>
            <Link href="/events" className="group inline-flex items-center gap-2 text-sm font-bold text-gold-400 transition-colors hover:text-gold-300">
              <svg className="h-4 w-4 rotate-180 transition-transform group-hover:-translate-x-1" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <path d="M3 10h13m0 0-5-5m5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              All Events
            </Link>
            <span className="mt-6 inline-block rounded-full bg-gold-500 px-3.5 py-1.5 text-[0.62rem] font-bold uppercase tracking-[0.18em] text-navy-950">
              {e.category}
            </span>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              {e.title}
            </h1>
            <div className="mt-6 flex flex-wrap gap-x-8 gap-y-3 text-sm text-cream-100/80">
              <p className="flex items-center gap-2">
                <MiniIcon name="calendar" className="h-4 w-4 text-gold-400" />
                {d.weekday}, {d.month} {d.day}, {d.year}
              </p>
              <p className="flex items-center gap-2">
                <MiniIcon name="note" className="h-4 w-4 text-gold-400" />
                {e.startTime}
                {e.endTime ? ` – ${e.endTime}` : ""}
              </p>
              <p className="flex items-center gap-2">
                <MiniIcon name="pin" className="h-4 w-4 text-gold-400" />
                {e.location}
              </p>
            </div>
            {e.speaker && (
              <p className="mt-3 text-sm text-cream-100/60">
                Featured: <span className="font-semibold text-gold-300">{e.speaker}</span>
              </p>
            )}
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          <div>
            <Reveal>
              <p className="font-display text-xl italic leading-relaxed text-navy-800">{e.description}</p>
              {e.details && (
                <div className="mt-6 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
                  {activities.length > 1 ? (
                    activities.map((p) => <p key={p}>{p}</p>)
                  ) : (
                    <p>{e.details}</p>
                  )}
                </div>
              )}
            </Reveal>

            <Reveal delay={100}>
              <div className="mt-8">
                <SampleNote>
                  Event location &amp; speaker details are sample placeholders — replace with your official information.
                </SampleNote>
              </div>
            </Reveal>
          </div>

          <aside className="lg:sticky lg:top-28 lg:self-start">
            <Reveal delay={80}>
              <div className="card-surface p-6 sm:p-7">
                <h2 className="font-display text-2xl font-medium text-navy-900">
                  {e.registrationOpen ? "Save Your Place" : "Event Details"}
                </h2>
                <div className="mt-4 space-y-2.5 rounded-xl bg-cream-100/70 p-4 text-sm text-ink-700">
                  <p className="flex items-center gap-2.5">
                    <MiniIcon name="calendar" className="h-4 w-4 text-gold-600" />
                    {d.weekday}, {d.month} {d.day}, {d.year}
                  </p>
                  <p className="flex items-center gap-2.5">
                    <MiniIcon name="note" className="h-4 w-4 text-gold-600" />
                    {e.startTime}
                    {e.endTime ? ` – ${e.endTime}` : ""}
                  </p>
                  <p className="flex items-start gap-2.5">
                    <MiniIcon name="pin" className="mt-0.5 h-4 w-4 shrink-0 text-gold-600" />
                    {e.location}
                  </p>
                  <a
                    href={site.directionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-sm font-bold text-gold-700 hover:text-gold-600"
                  >
                    Get Directions
                    <svg className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                      <path d="M3 10h13m0 0-5-5m5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </a>
                </div>
                {e.registrationOpen ? (
                  <div className="mt-5">
                    <RegisterForm eventTitle={e.title} />
                    <p className="mt-3 text-xs text-ink-300">
                      Registrations are stored securely and only used to
                      coordinate this event.
                    </p>
                  </div>
                ) : (
                  <p className="mt-5 rounded-xl bg-cream-100 p-4 text-sm text-ink-700">
                    Registration for this event has closed. If you would still
                    like to attend, please <Link href="/contact" className="font-bold text-gold-700">contact our office</Link>.
                  </p>
                )}
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}
