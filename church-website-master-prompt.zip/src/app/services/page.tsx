import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Reveal, SectionHeading, SampleNote, ArrowIcon, MiniIcon } from "@/components/ui";
import { site } from "@/lib/site";
import { img } from "@/lib/images";

export const metadata: Metadata = {
  title: "Services — Sunday Worship, Midweek & Prayer",
  description:
    "Discover REDEEM's services: Sunday worship at 08:00 & 10:00 AM, Wednesday midweek teaching, Friday prayer and special services. See what to expect.",
};

const services = [
  {
    icon: "sun",
    name: "Sunday Worship",
    times: ["08:00 AM — First Service", "10:00 AM — Second Service"],
    body: "Our flagship gathering. Exuberant worship, a grounded message from Scripture, and a room where you are known. Children's ministry runs during both services, and everyone — including first-timers — is personally greeted.",
    points: ["Worship, teaching & prayer", "Children's ministry (birth–grade 6)", "Coffee & conversation after service"],
  },
  {
    icon: "note",
    name: "Midweek Service",
    times: ["Wednesday — 06:00 PM"],
    body: "A deeper dive into the Word. We slow down, study Scripture together and pray. The first Wednesday of each month includes communion. An excellent weeknight way to grow if Sundays get crowded.",
    points: ["Extended Bible teaching", "Communion on the 1st Wednesday", "Shorter — ideal with kids or busy weeks"],
  },
  {
    icon: "candle",
    name: "Prayer Service",
    times: ["Friday — 06:00 PM"],
    body: "The heartbeat of REDEEM. We gather to pray in the open — for the church, our families, our city and the nations. New to prayer? Sit in the front row; we will walk you through it.",
    points: ["Guided corporate intercession", "Prayer for visitors who step forward", "Prayer request ministry on site"],
  },
  {
    icon: "flame",
    name: "Special Services",
    times: ["Throughout the year"],
    body: "Night of Encounter, Christmas, Easter, harvest thanksgiving and our annual Forward Conference. These are the highlight moments of the REDEEM calendar — join our newsletter to hear about them first.",
    points: ["Night of Encounter & revival nights", "Seasonal celebrations", "Annual Forward Conference"],
  },
];

const expectSteps = [
  { n: "01", title: "You arrive", body: "Come 10–15 minutes early. Our welcome team will greet you, and first-timers receive a simple guide to the service. Parking is available on site (sample — confirm details)." },
  { n: "02", title: "You worship", body: "Expect real, expressive worship — music led by our team, with the congregation invited in, not just watching. If you sit, that is perfectly fine too." },
  { n: "03", title: "You hear the Word", body: "A clear, grounded message from the Scriptures — practical enough to live by on Monday morning." },
  { n: "04", title: "You connect", body: "After the service, stay for coffee and conversation. The hospitality team loves first-timers — they know your name and will check in on you the following week." },
];

export default function ServicesPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.handsRaised} alt="" fill sizes="100vw" className="object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/60" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Gather With Us
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              Every week, the house is open{" "}
              <em className="italic text-gold-400">and the lights are on</em>
            </h1>
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <Link href="/visit" className="btn-gold">
                Plan Your Visit
                <ArrowIcon />
              </Link>
              <a href={site.directionsUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost-light">
                <MiniIcon name="pin" className="h-4 w-4" />
                Get Directions
              </a>
            </div>
            <div className="mt-8">
              <SampleNote dark>The service times shown are sample placeholders — replace with your official times.</SampleNote>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Service cards */}
      <section className="py-20 lg:py-24">
        <div className="container-redeem">
          <div className="grid gap-6 md:grid-cols-2">
            {services.map((s, i) => (
              <Reveal key={s.name} delay={(i % 2) * 100} className="h-full">
                <article className="card-surface h-full p-7 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/40 hover:shadow-lift sm:p-8">
                  <div className="flex items-center justify-between gap-4">
                    <span className="flex h-12 w-12 items-center justify-center rounded-full bg-navy-800 text-gold-400">
                      <MiniIcon name={s.icon} className="h-5.5 w-5.5" />
                    </span>
                    <div className="text-right">
                      {s.times.map((t) => (
                        <p key={t} className="font-display text-base text-navy-900 sm:text-lg">
                          {t}
                        </p>
                      ))}
                    </div>
                  </div>
                  <h2 className="mt-5 font-display text-2xl font-medium text-navy-900">{s.name}</h2>
                  <p className="mt-3 text-sm leading-relaxed text-ink-700">{s.body}</p>
                  <ul className="mt-5 space-y-2 border-t border-navy-900/8 pt-5">
                    {s.points.map((p) => (
                      <li key={p} className="flex items-center gap-2.5 text-sm text-ink-500">
                        <svg className="h-3.5 w-3.5 text-gold-600" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true">
                          <path d="M5 0L10 5L5 10L0 5Z" />
                        </svg>
                        {p}
                      </li>
                    ))}
                  </ul>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* What to expect */}
      <section id="expect" className="scroll-mt-24 border-y border-navy-900/8 bg-cream-100/60 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="First Time?"
              title="What happens at REDEEM"
              intro="No rituals to decode, no pressure to perform. Here is the honest, minute-by-minute picture of a Sunday at REDEEM."
              align="center"
            />
          </Reveal>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {expectSteps.map((s, i) => (
              <Reveal key={s.n} delay={i * 90} className="h-full">
                <div className="h-full rounded-2xl border border-navy-900/8 bg-white/80 p-6">
                  <p className="font-display text-4xl font-semibold text-gold-500/70">{s.n}</p>
                  <h3 className="mt-3 font-display text-lg font-medium text-navy-900">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500">{s.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-10 text-center">
            <Link href="/visit" className="btn-dark">
              See the Full Plan-Your-Visit Guide
              <ArrowIcon />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Children + practical */}
      <section className="py-20 lg:py-24">
        <div className="container-redeem grid gap-12 lg:grid-cols-2">
          <Reveal>
            <SectionHeading
              eyebrow="For the Littlest Members"
              title="Children's ministry runs during both Sunday services"
            />
            <div className="mt-6 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
              <p>
                From birth to grade 6, our children's ministry provides a safe,
                joyful and biblically rich environment — with trained,
                vetted teams and secure check-in.
              </p>
              <p>
                First time? Let the team know at check-in and your child's
                leader will be briefed before the service begins.
              </p>
            </div>
            <Link href="/ministries/childrens-ministry" className="btn-outline-dark group mt-8">
              Explore Children's Ministry
              <ArrowIcon />
            </Link>
          </Reveal>
          <Reveal delay={120}>
            <div className="card-surface h-full p-7 sm:p-8">
              <h3 className="font-display text-xl font-medium text-navy-900">
                Practical details
              </h3>
              <ul className="mt-5 space-y-4 text-sm text-ink-700">
                {[
                  { icon: "pin", text: `${site.address.line1}, ${site.address.city} (sample address — confirm with the church office).` },
                  { icon: "calendar", text: "Doors open 20 minutes before each service. Arriving late? Slip in quietly through the side door." },
                  { icon: "hand", text: "Dress comfortably — we do not judge outfits. Come as you are, that is the whole point." },
                  { icon: "note", text: "Services are typically 75–90 minutes, including children's check-in time." },
                ].map((li) => (
                  <li key={li.text} className="flex items-start gap-3">
                    <span className="mt-0.5 text-gold-600">
                      <MiniIcon name={li.icon} className="h-4.5 w-4.5" />
                    </span>
                    {li.text}
                  </li>
                ))}
              </ul>
              <div className="mt-7 flex flex-wrap gap-3 border-t border-navy-900/8 pt-6">
                <a href={site.directionsUrl} target="_blank" rel="noopener noreferrer" className="btn-gold !px-5 !py-2.5 text-xs">
                  Get Directions
                </a>
                <Link href="/contact" className="btn-outline-dark !px-5 !py-2.5 text-xs">
                  Contact Us
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
