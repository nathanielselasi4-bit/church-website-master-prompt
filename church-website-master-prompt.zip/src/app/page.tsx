import Image from "next/image";
import Link from "next/link";
import { asc, desc, sql } from "drizzle-orm";
import { EventCard, TestimonialCard, MinistryCard } from "@/components/cards";
import { Reveal, SampleNote, MiniIcon, PlayIcon, ArrowIcon } from "@/components/ui";
import { dateParts, formatDate } from "@/lib/format";
import { db } from "@/db";
import {
  events as eventsTable,
  ministries as ministriesTable,
  sermons as sermonsTable,
} from "@/db/schema";
import { site, verseOfDay } from "@/lib/site";
import { img } from "@/lib/images";

export const dynamic = "force-dynamic";

const testimonials = [
  {
    quote: "REDEEM became the place where my faith was restored. I came through the doors empty, and something changed in the room.",
    name: "A. K.",
    detail: "Sample testimonial — member story",
  },
  {
    quote: "Through the ministry, I discovered purpose and a community that felt like home. I finally stopped attending church and started belonging to one.",
    name: "J. M.",
    detail: "Sample testimonial — member story",
  },
  {
    quote: "As a first-time visitor, I expected to feel out of place. Instead, I was welcomed by name before the service even started. I came back the following week — on purpose.",
    name: "R. O.",
    detail: "Sample testimonial — first-time visitor",
  },
];

export default async function HomePage() {
  const today = new Date().toISOString().slice(0, 10);

  const [sermons, upcoming, ministries] = await Promise.all([
    db
      .select()
      .from(sermonsTable)
      .where(sql`${sermonsTable.published} = true`)
      .orderBy(desc(sermonsTable.sermonDate))
      .limit(4),
    db
      .select()
      .from(eventsTable)
      .where(sql`${eventsTable.eventDate} >= ${today}`)
      .orderBy(asc(eventsTable.eventDate))
      .limit(4),
    db.select().from(ministriesTable).orderBy(asc(ministriesTable.sort)),
  ]);

  const featuredSermon = sermons.find((s) => s.featured) ?? sermons[0];
  const latestSermons = sermons.filter((s) => s.id !== featuredSermon?.id).slice(0, 3);
  const featuredEvent =
    upcoming.find((e) => e.featured) ?? upcoming[0];
  const otherEvents = upcoming.filter((e) => e.id !== featuredEvent?.id).slice(0, 3);
  const verse = verseOfDay();

  const quickActions = [
    { icon: "pin", title: "Plan Your Visit", sub: "What to expect, where to park, who to meet", href: "/visit" },
    { icon: "play", title: "Watch a Sermon", sub: "Latest messages, video & audio", href: "/sermons" },
    { icon: "candle", title: "Prayer Request", sub: "We will stand with you in prayer", href: "/prayer" },
    { icon: "calendar", title: "Upcoming Events", sub: "Conferences, youth nights, outreach", href: "/events" },
    { icon: "heart", title: "Give", sub: "Safely support the mission of REDEEM", href: "/give" },
  ];

  const services = site.serviceTimes.items;

  return (
    <>
      {/* ============================ HERO ============================ */}
      <section className="relative -mt-[4.5rem] flex min-h-[92svh] items-end overflow-hidden bg-navy-950 md:-mt-[6.75rem]">
        <div className="absolute inset-0" aria-hidden="true">
          <Image
            src={img.hero}
            alt=""
            fill
            priority
            sizes="100vw"
            className="kenburns object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-950/70 to-navy-950/30" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/20 to-navy-950/40" />
        </div>

        <div className="container-redeem relative z-10 grid w-full gap-10 pb-16 pt-36 lg:grid-cols-[1.5fr_1fr] lg:items-end lg:pb-24">
          <div>
            <p className="line-mask">
              <span className="line-rise" style={{ animationDelay: "0.05s" }}>
                <span className="eyebrow-light">
                  <span className="gold-hairline" aria-hidden="true" />
                  {site.tagline}
                </span>
              </span>
            </p>
            <h1 className="mt-5 font-display text-[2.6rem] font-medium leading-[1.06] tracking-tight text-cream-50 sm:text-6xl lg:text-[4.4rem]">
              <span className="line-mask">
                <span className="line-rise" style={{ animationDelay: "0.15s" }}>
                  A place to <em className="italic text-gold-400">encounter</em> God.
                </span>
              </span>
              <span className="line-mask">
                <span className="line-rise" style={{ animationDelay: "0.3s" }}>
                  A community to discover purpose.
                </span>
              </span>
            </h1>
            <div className="line-mask">
              <p className="line-rise mt-6 max-w-xl text-base leading-relaxed text-cream-100/80 sm:text-lg" style={{ animationDelay: "0.45s" }}>
                {site.shortDescription}
              </p>
            </div>
            <div className="line-mask">
              <div className="line-rise mt-8 flex flex-wrap items-center gap-4" style={{ animationDelay: "0.6s" }}>
                <Link href="/visit" className="btn-gold">
                  Plan Your Visit
                  <ArrowIcon />
                </Link>
                <Link href="/sermons" className="btn-ghost-light">
                  <PlayIcon className="h-4 w-4" />
                  Watch Latest Sermon
                </Link>
              </div>
            </div>
          </div>

          {/* This Sunday card */}
          <div className="line-mask">
            <div className="line-rise rounded-2xl border border-gold-400/25 bg-navy-900/75 p-6 shadow-lift backdrop-blur-md sm:p-7" style={{ animationDelay: "0.5s" }}>
              <div className="flex items-center justify-between">
                <p className="text-[0.68rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                  This Sunday
                </p>
                <span className="sample-badge-dark">Sample times</span>
              </div>
              <ul className="mt-5 space-y-4">
                {services.filter((s) => s.day === "Sunday").map((s) => (
                  <li key={s.label} className="flex items-baseline justify-between gap-4 border-b border-cream-50/10 pb-3">
                    <div>
                      <p className="font-display text-lg text-cream-50">{s.label}</p>
                      <p className="text-xs text-cream-100/60">{s.note}</p>
                    </div>
                    <p className="font-display text-xl text-gold-400">{s.time}</p>
                  </li>
                ))}
              </ul>
              <p className="mt-4 flex items-center gap-2 text-sm text-cream-100/70">
                <MiniIcon name="pin" className="h-4 w-4 text-gold-400" />
                {site.address.line1}, {site.address.city}
              </p>
              <div className="mt-5 flex gap-3">
                <Link href="/visit" className="btn-gold flex-1 !px-4 !py-2.5 text-xs">
                  Plan Your Visit
                </Link>
                <a
                  href={site.directionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost-light !px-4 !py-2.5 text-xs"
                >
                  Directions
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================ VERSE BAND ============================ */}
      <section className="border-b border-gold-500/15 bg-navy-900">
        <div className="container-redeem py-8 text-center">
          <Reveal>
            <p className="font-display text-lg italic leading-relaxed text-cream-100/90 sm:text-xl">
              “{verse.text}”
            </p>
            <p className="mt-2 text-[0.68rem] font-bold uppercase tracking-[0.28em] text-gold-400">
              {verse.ref}
            </p>
          </Reveal>
        </div>
      </section>

      {/* ============================ QUICK ACTIONS ============================ */}
      <section aria-labelledby="quick-actions" className="relative z-20 -mt-10 pb-4">
        <div className="container-redeem">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 lg:gap-4">
            {quickActions.map((a, i) => (
              <Reveal key={a.title} delay={i * 70} className="h-full">
                <Link
                  href={a.href}
                  className="group card-surface flex h-full flex-col items-start gap-3 p-5 transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-500/40 hover:shadow-lift"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-navy-800 text-gold-400 transition-colors duration-500 group-hover:bg-gold-500 group-hover:text-navy-950">
                    <MiniIcon name={a.icon} className="h-5 w-5" />
                  </span>
                  <span className="font-display text-base font-medium leading-snug text-navy-900">
                    {a.title}
                  </span>
                  <span className="text-xs leading-relaxed text-ink-500">{a.sub}</span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============================ WELCOME ============================ */}
      <section className="py-20 lg:py-28">
        <div className="container-redeem grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal className="relative order-2 lg:order-1">
            <div className="absolute -left-4 -top-4 h-full w-full rounded-2xl border border-gold-500/40" aria-hidden="true" />
            <div className="relative overflow-hidden rounded-2xl">
              <Image
                src={img.welcome}
                alt="Members of REDEEM standing together in worship"
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="aspect-[4/5] w-full object-cover sm:aspect-[4/3.4]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950/40 to-transparent" />
            </div>
          </Reveal>
          <Reveal delay={120} className="order-1 lg:order-2">
            <p className="eyebrow">
              <span className="gold-hairline" aria-hidden="true" />
              Welcome to REDEEM
            </p>
            <h2 className="mt-4 font-display text-3xl font-medium leading-[1.12] tracking-tight text-navy-900 sm:text-4xl lg:text-[2.75rem]">
              You are welcome here.{" "}
              <em className="italic text-gold-600">No matter where you are.</em>
            </h2>
            <div className="mt-6 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
              <p>
                REDEEM began with a simple conviction: that church should not
                feel like a performance you watch, but like a household you
                belong to. We gather to worship God with our whole hearts, to
                take the Scriptures seriously, and to love our neighbours in
                ways they can see.
              </p>
              <p>
                Whether you are taking your first step, rebuilding a broken
                faith, or looking for a place to serve — there is a seat for
                you, a story to hear, and a family that is genuinely glad you
                came.
              </p>
            </div>
            <p className="mt-6 font-display text-lg italic text-navy-800">
              “Come as you are. We saved you a seat.”
            </p>
            <p className="mt-1 text-xs font-bold uppercase tracking-[0.18em] text-ink-300">
              — Senior Pastor, REDEEM <span className="normal-case tracking-normal">(sample profile)</span>
            </p>
            <Link href="/about" className="btn-dark group mt-8">
              Learn More About REDEEM
              <ArrowIcon />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ============================ SERVICE TIMES ============================ */}
      <section className="relative overflow-hidden bg-navy-950 py-20 lg:py-24">
        <div
          className="absolute inset-0 opacity-[0.06]"
          aria-hidden="true"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, #c9a227 0, transparent 32%), radial-gradient(circle at 80% 70%, #c9a227 0, transparent 36%)",
          }}
        />
        <div className="container-redeem relative">
          <Reveal>
            <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div className="max-w-xl">
                <p className="eyebrow-light">
                  <span className="gold-hairline" aria-hidden="true" />
                  Gather With Us
                </p>
                <h2 className="mt-4 font-display text-3xl font-medium tracking-tight text-cream-50 sm:text-4xl">
                  Service Times
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-cream-100/60">
                  Four ways to gather every week. The times below are
                  placeholders — confirm them with the church office before
                  planning your visit.
                </p>
              </div>
              <Link href="/services" className="btn-ghost-light shrink-0">
                All Service Details
                <ArrowIcon />
              </Link>
            </div>
          </Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((s, i) => (
              <Reveal key={s.label} delay={i * 80} className="h-full">
                <div className="group h-full rounded-2xl border border-cream-50/10 bg-navy-900/60 p-6 transition-all duration-500 hover:-translate-y-1 hover:border-gold-400/40">
                  <p className="text-[0.65rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                    {s.day}
                  </p>
                  <p className="mt-3 font-display text-2xl text-cream-50">
                    {s.time}
                  </p>
                  <p className="mt-1 text-sm font-semibold text-cream-100/85">
                    {s.label}
                  </p>
                  <p className="mt-3 text-xs leading-relaxed text-cream-100/50">
                    {s.note}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============================ SERMONS ============================ */}
      <section className="py-20 lg:py-28">
        <div className="container-redeem">
          <Reveal>
            <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="eyebrow">
                  <span className="gold-hairline" aria-hidden="true" />
                  Sermon Library
                </p>
                <h2 className="mt-4 font-display text-3xl font-medium tracking-tight text-navy-900 sm:text-4xl">
                  Messages for the road ahead
                </h2>
              </div>
              <Link href="/sermons" className="group inline-flex items-center gap-2 text-sm font-bold text-gold-700">
                Browse All Sermons
                <ArrowIcon />
              </Link>
            </div>
          </Reveal>

          {featuredSermon ? (
            <div className="mt-10 grid gap-6 lg:grid-cols-5">
              <Reveal className="lg:col-span-3">
                <Link
                  href={`/sermons/${featuredSermon.slug}`}
                  className="group relative block h-full overflow-hidden rounded-2xl shadow-soft"
                >
                  <div className="relative aspect-video overflow-hidden lg:aspect-[16/9]">
                    <Image
                      src={featuredSermon.thumbnail}
                      alt={`Featured sermon — ${featuredSermon.title}`}
                      fill
                      sizes="(max-width: 1024px) 100vw, 60vw"
                      className="object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-navy-950/25 to-transparent" />
                    <span className="absolute left-5 top-5 rounded-full bg-gold-500 px-3.5 py-1.5 text-[0.62rem] font-bold uppercase tracking-[0.18em] text-navy-950">
                      Latest Sermon
                    </span>
                    <span className="absolute right-5 top-5 flex h-14 w-14 items-center justify-center rounded-full bg-cream-50/15 text-cream-50 backdrop-blur-sm transition-all duration-500 group-hover:scale-110 group-hover:bg-gold-500 group-hover:text-navy-950">
                      <PlayIcon className="h-5 w-5 translate-x-0.5" />
                    </span>
                    <div className="absolute inset-x-0 bottom-0 p-6">
                      <p className="text-[0.68rem] font-bold uppercase tracking-[0.2em] text-gold-400">
                        {formatDate(featuredSermon.sermonDate)} · {featuredSermon.category}
                      </p>
                      <h3 className="mt-2 font-display text-2xl font-medium text-cream-50 sm:text-3xl">
                        {featuredSermon.title}
                      </h3>
                      <p className="mt-1 text-sm text-cream-100/75">
                        {featuredSermon.speaker} · {featuredSermon.scripture}
                      </p>
                    </div>
                  </div>
                </Link>
              </Reveal>
              <div className="grid gap-4 lg:col-span-2">
                {latestSermons.map((s, i) => (
                  <Reveal key={s.id} delay={i * 80}>
                    <Link
                      href={`/sermons/${s.slug}`}
                      className="group card-surface flex items-center gap-4 p-4 transition-all duration-500 hover:-translate-y-0.5 hover:border-gold-500/40"
                    >
                      <div className="relative h-20 w-28 shrink-0 overflow-hidden rounded-xl">
                        <Image
                          src={s.thumbnail}
                          alt=""
                          fill
                          sizes="112px"
                          className="object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-gold-600">
                          {formatDate(s.sermonDate)}
                        </p>
                        <h3 className="mt-1 truncate font-display text-base font-medium text-navy-900">
                          {s.title}
                        </h3>
                        <p className="mt-0.5 truncate text-xs text-ink-500">
                          {s.speaker} · {s.category}
                        </p>
                      </div>
                    </Link>
                  </Reveal>
                ))}
              </div>
            </div>
          ) : (
            <Reveal className="mt-10">
              <div className="card-surface flex flex-col items-center gap-3 p-12 text-center">
                <MiniIcon name="note" className="h-8 w-8 text-gold-500" />
                <p className="font-display text-xl text-navy-900">No sermons published yet</p>
                <p className="text-sm text-ink-500">Check back soon — new messages are added every week.</p>
              </div>
            </Reveal>
          )}
        </div>
      </section>

      {/* ============================ ABOUT TEASER ============================ */}
      <section className="border-y border-navy-900/8 bg-cream-100/60 py-20 lg:py-24">
        <div className="container-redeem grid gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal>
            <p className="eyebrow">
              <span className="gold-hairline" aria-hidden="true" />
              Who We Are
            </p>
            <h2 className="mt-4 font-display text-3xl font-medium leading-[1.12] tracking-tight text-navy-900 sm:text-4xl">
              A family of believers on a mission
            </h2>
            <div className="mt-6 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
              <p>
                REDEEM exists to point people to Jesus — through worship that
                moves hearts, Scripture that holds weight, and community that
                carries weight with you. We are ordinary people gathered by an
                extraordinary grace.
              </p>
              <p>
                Our mission is to make disciples; our vision is a city shaped
                by the love of Christ; and our values — faith, hope, grace,
                purpose and community — shape everything we do.
              </p>
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              {[
                { label: "Our Story", href: "/about#story" },
                { label: "Vision", href: "/about#vision" },
                { label: "Mission", href: "/about#mission" },
                { label: "Values", href: "/about#values" },
              ].map((c) => (
                <Link key={c.href} href={c.href} className="btn-outline-dark !px-5 !py-2.5 text-xs">
                  {c.label}
                </Link>
              ))}
            </div>
          </Reveal>
          <Reveal delay={140} className="relative">
            <div className="absolute -right-4 -top-4 h-full w-full rounded-2xl border border-gold-500/40" aria-hidden="true" />
            <div className="relative overflow-hidden rounded-2xl">
              <Image
                src={img.stainedLight}
                alt="Light falling through a church window at REDEEM"
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============================ MINISTRIES ============================ */}
      <section className="py-20 lg:py-28">
        <div className="container-redeem">
          <Reveal>
            <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
              <div className="max-w-xl">
                <p className="eyebrow">
                  <span className="gold-hairline" aria-hidden="true" />
                  Ministries
                </p>
                <h2 className="mt-4 font-display text-3xl font-medium tracking-tight text-navy-900 sm:text-4xl">
                  Find your place to grow — and serve
                </h2>
              </div>
              <Link href="/ministries" className="group inline-flex items-center gap-2 text-sm font-bold text-gold-700">
                View All Ministries
                <ArrowIcon />
              </Link>
            </div>
          </Reveal>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {ministries.map((m, i) => (
              <Reveal key={m.slug} delay={(i % 4) * 70}>
                <MinistryCard ministry={m} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============================ EVENTS ============================ */}
      <section className="bg-navy-950 py-20 lg:py-28">
        <div className="container-redeem">
          <Reveal>
            <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
              <div className="max-w-xl">
                <p className="eyebrow-light">
                  <span className="gold-hairline" aria-hidden="true" />
                  Upcoming Events
                </p>
                <h2 className="mt-4 font-display text-3xl font-medium tracking-tight text-cream-50 sm:text-4xl">
                  What&apos;s happening at REDEEM
                </h2>
              </div>
              <Link href="/events" className="btn-ghost-light">
                Full Event Calendar
                <ArrowIcon />
              </Link>
            </div>
          </Reveal>

          {featuredEvent ? (
            <div className="mt-10 grid gap-6 lg:grid-cols-3">
              <Reveal className="lg:col-span-2">
                <EventCard event={featuredEvent} large />
              </Reveal>
              <div className="flex flex-col gap-4">
                {otherEvents.slice(0, 2).map((e, i) => {
                  const d = dateParts(e.eventDate);
                  return (
                    <Reveal key={e.id} delay={(i + 1) * 80} className="flex-1">
                      <Link
                        href={`/events/${e.slug}`}
                        className="group flex h-full items-center gap-5 rounded-2xl border border-cream-50/10 bg-navy-900/60 p-5 transition-all duration-500 hover:-translate-y-1 hover:border-gold-400/40"
                      >
                        <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl bg-navy-800">
                          <span className="font-display text-2xl leading-none text-gold-400">{d.day}</span>
                          <span className="mt-0.5 text-[0.6rem] font-bold uppercase tracking-widest text-cream-100/70">{d.month}</span>
                        </div>
                        <div className="min-w-0">
                          <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-gold-400">{e.category}</p>
                          <h3 className="mt-1 truncate font-display text-lg text-cream-50">{e.title}</h3>
                          <p className="mt-1 text-xs text-cream-100/60">{e.startTime} · {e.location}</p>
                        </div>
                      </Link>
                    </Reveal>
                  );
                })}
                {otherEvents.length < 2 && (
                  <Reveal className="flex-1">
                    <div className="flex h-full flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-cream-50/15 p-6 text-center">
                      <p className="font-display text-lg text-cream-100/80">More events coming</p>
                      <p className="text-xs text-cream-100/50">Join our newsletter so you never miss one.</p>
                    </div>
                  </Reveal>
                )}
              </div>
            </div>
          ) : (
            <Reveal className="mt-10">
              <div className="rounded-2xl border border-dashed border-cream-50/20 p-14 text-center">
                <MiniIcon name="calendar" className="mx-auto h-8 w-8 text-gold-400" />
                <p className="mt-4 font-display text-2xl text-cream-50">No upcoming events scheduled</p>
                <p className="mt-2 text-sm text-cream-100/60">
                  Subscribe to our newsletter and we will let you know the moment new events are announced.
                </p>
              </div>
            </Reveal>
          )}
        </div>
      </section>

      {/* ============================ TESTIMONIALS ============================ */}
      <section className="py-20 lg:py-28">
        <div className="container-redeem">
          <Reveal>
            <SectionHeadCenter
              eyebrow="Testimonies"
              title="Stories from our family"
              intro="Real people, real encounters — a few words from those who call REDEEM home."
            />
          </Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <Reveal key={t.name} delay={i * 100}>
                <TestimonialCard quote={t.quote} name={t.name} detail={t.detail} />
              </Reveal>
            ))}
          </div>
          <Reveal delay={200}>
            <div className="mt-8">
              <SampleNote>
                Testimonials shown are clearly-marked sample placeholders, not claims about real people. Replace with your congregation&apos;s stories.
              </SampleNote>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============================ PRAYER CTA ============================ */}
      <section className="relative overflow-hidden bg-navy-900 py-20">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.candles} alt="" fill sizes="100vw" className="object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-950/80 to-navy-950/60" />
        </div>
        <div className="container-redeem relative grid items-center gap-10 lg:grid-cols-[1.4fr_1fr]">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              We Pray For You
            </p>
            <h2 className="mt-4 font-display text-3xl font-medium leading-[1.15] tracking-tight text-cream-50 sm:text-4xl">
              You don&apos;t have to carry it alone.
            </h2>
            <p className="mt-4 max-w-xl text-[0.975rem] leading-relaxed text-cream-100/75">
              Your prayer matters. Our prayer team is ready to stand with you —
              confidentially, consistently, and without judgement. Share what
              is on your heart and we will lift it with you.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/prayer" className="btn-gold">
                Submit a Prayer Request
              </Link>
              <Link href="/ministries/prayer-ministry" className="btn-ghost-light">
                Meet the Prayer Team
              </Link>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <blockquote className="rounded-2xl border border-gold-400/25 bg-navy-950/60 p-8 backdrop-blur-sm">
              <p className="font-display text-xl italic leading-relaxed text-cream-100/90">
                “Pray for one another, and then you will be healed.”
              </p>
              <footer className="mt-4 text-[0.68rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                James 5:16
              </footer>
            </blockquote>
          </Reveal>
        </div>
      </section>

      {/* ============================ GIVE CTA ============================ */}
      <section className="bg-gradient-to-r from-gold-500 to-gold-400 py-16">
        <div className="container-redeem flex flex-col items-start gap-8 lg:flex-row lg:items-center lg:justify-between">
          <Reveal className="max-w-2xl">
            <h2 className="font-display text-3xl font-medium leading-[1.12] tracking-tight text-navy-950 sm:text-4xl">
              Your generosity helps REDEEM advance the Gospel.
            </h2>
            <p className="mt-3 text-[0.95rem] font-medium leading-relaxed text-navy-900/80">
              Every gift strengthens our community, serves our city, and carries
              the mission further. Give online, in person, or by direct transfer.
            </p>
          </Reveal>
          <Reveal delay={120} className="flex flex-wrap gap-4">
            <Link href="/give" className="btn-dark">
              <MiniIcon name="heart" className="h-4 w-4" />
              Give Online
            </Link>
            <a
              href={site.directionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn text-navy-950 hover:bg-navy-950/10"
            >
              Find Us
            </a>
          </Reveal>
        </div>
      </section>

      {/* ============================ FINAL CTA ============================ */}
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-32">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.silhouettes} alt="" fill sizes="100vw" className="kenburns object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/70 to-navy-950" />
        </div>
        <div className="container-redeem relative text-center">
          <Reveal>
            <p className="eyebrow-light justify-center">
              <span className="gold-hairline" aria-hidden="true" />
              Your Next Step
              <span className="gold-hairline rotate-180" aria-hidden="true" />
            </p>
            <h2 className="mx-auto mt-5 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              Come as you are.
              <br />
              <em className="italic text-gold-400">Leave on purpose.</em>
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-cream-100/75">
              One Sunday morning is all it takes to see, hear and feel what
              REDEEM is. We would be honoured to welcome you.
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link href="/visit" className="btn-gold !px-8 !py-4 text-base">
                Plan Your Visit
                <ArrowIcon />
              </Link>
              <Link href="/sermons" className="btn-ghost-light !px-8 !py-4 text-base">
                <PlayIcon className="h-4 w-4" />
                Watch Latest Sermon
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}

function SectionHeadCenter({
  eyebrow,
  title,
  intro,
}: {
  eyebrow: string;
  title: string;
  intro: string;
}) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="eyebrow justify-center">
        <span className="gold-hairline" aria-hidden="true" />
        {eyebrow}
        <span className="gold-hairline rotate-180" aria-hidden="true" />
      </p>
      <h2 className="mt-4 font-display text-3xl font-medium tracking-tight text-navy-900 sm:text-4xl">
        {title}
      </h2>
      <p className="mt-4 text-[0.975rem] leading-relaxed text-ink-500">{intro}</p>
    </div>
  );
}
