import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { eq, and, desc, ne, sql } from "drizzle-orm";
import { notFound } from "next/navigation";
import { Reveal, MiniIcon } from "@/components/ui";
import { formatDate } from "@/lib/format";
import { SermonCard } from "@/components/cards";
import { db } from "@/db";
import { sermons as sermonsTable } from "@/db/schema";
import { site } from "@/lib/site";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const row = await db
    .select()
    .from(sermonsTable)
    .where(eq(sermonsTable.slug, slug))
    .limit(1);
  const s = row[0];
  if (!s) return { title: "Sermon Not Found" };
  return {
    title: `${s.title} — ${s.scripture}`,
    description: s.summary,
    openGraph: {
      title: `${s.title} | REDEEM Sermons`,
      description: s.summary,
      images: s.thumbnail ? [s.thumbnail] : undefined,
      type: "article",
    },
  };
}

export default async function SermonDetailPage({ params }: Props) {
  const { slug } = await params;
  const sermon = await db
    .select()
    .from(sermonsTable)
    .where(eq(sermonsTable.slug, slug))
    .limit(1);
  const s = sermon[0];
  if (!s) notFound();

  const relatedSermons = await db
    .select()
    .from(sermonsTable)
    .where(
      and(
        eq(sermonsTable.category, s.category),
        ne(sermonsTable.id, s.id),
        sqlPublished(),
      ),
    )
    .orderBy(desc(sermonsTable.sermonDate))
    .limit(3);

  const shareUrl = `${site.url}/sermons/${s.slug}`;

  return (
    <>
      <section className="bg-navy-950 py-16 lg:py-20">
        <div className="container-redeem">
          <Reveal>
            <Link href="/sermons" className="group inline-flex items-center gap-2 text-sm font-bold text-gold-400 transition-colors hover:text-gold-300">
              <svg className="h-4 w-4 rotate-180 transition-transform group-hover:-translate-x-1" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <path d="M3 10h13m0 0-5-5m5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              All Sermons
            </Link>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <span className="rounded-full bg-gold-500 px-3.5 py-1.5 text-[0.62rem] font-bold uppercase tracking-[0.18em] text-navy-950">
                {s.category}
              </span>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-cream-100/50">
                {formatDate(s.sermonDate)}
              </span>
            </div>
            <h1 className="mt-4 max-w-3xl font-display text-3xl font-medium leading-[1.1] tracking-tight text-cream-50 sm:text-4xl lg:text-5xl">
              {s.title}
            </h1>
            <p className="mt-4 text-base text-cream-100/75">
              {s.speaker} · <em className="italic text-gold-300">{s.scripture}</em>
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          {/* Player column */}
          <div>
            <Reveal>
              <div className="overflow-hidden rounded-2xl bg-navy-950 shadow-lift">
                {s.videoUrl ? (
                  <div className="relative">
                    <video
                      controls
                      preload="metadata"
                      poster={s.thumbnail}
                      className="aspect-video w-full object-cover"
                    >
                      <source src={s.videoUrl} type="video/mp4" />
                      Your browser does not support embedded video.
                    </video>
                    <span className="pointer-events-none absolute left-4 top-4">
                      <span className="sample-badge-dark">Sample placeholder video — connect your sermon recording</span>
                    </span>
                  </div>
                ) : s.audioUrl ? (
                  <div className="relative">
                    <Image
                      src={s.thumbnail}
                      alt=""
                      fill
                      sizes="(max-width: 1024px) 100vw, 60vw"
                      className="object-cover opacity-60"
                    />
                    <div className="absolute inset-0 flex items-center justify-center p-6">
                      <div className="w-full max-w-md rounded-2xl border border-cream-50/15 bg-navy-950/85 p-6 backdrop-blur-md">
                        <p className="text-[0.65rem] font-bold uppercase tracking-[0.22em] text-gold-400">
                          Audio Sermon
                        </p>
                        <p className="mt-1 font-display text-lg text-cream-50">{s.title}</p>
                        <audio controls src={s.audioUrl} className="mt-4 w-full">
                          Your browser does not support embedded audio.
                        </audio>
                        <p className="mt-3 text-[0.65rem] text-cream-100/50">
                          Sample audio file — replace with the recorded teaching.
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    <Image
                      src={s.thumbnail}
                      alt={`Sermon — ${s.title}`}
                      fill
                      sizes="(max-width: 1024px) 100vw, 60vw"
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-navy-950/50 p-6">
                      <p className="rounded-xl border border-cream-50/20 bg-navy-950/80 px-5 py-3 text-sm text-cream-100/80">
                        Media for this sermon is being processed.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </Reveal>

            <Reveal delay={100}>
              <article className="mt-8 space-y-4 text-[0.975rem] leading-relaxed text-ink-700">
                <p className="font-display text-xl italic leading-relaxed text-navy-800">
                  {s.summary}
                </p>
                <p>{s.description}</p>
              </article>
            </Reveal>

            {relatedSermons.length > 0 && (
              <Reveal delay={150}>
                <div className="mt-14">
                  <h2 className="font-display text-2xl font-medium text-navy-900">
                    Keep growing — from the {s.category} series
                  </h2>
                  <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                    {relatedSermons.map((r) => (
                      <SermonCard key={r.id} sermon={r} />
                    ))}
                  </div>
                </div>
              </Reveal>
            )}
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            <Reveal delay={80}>
              <div className="card-surface p-6">
                <h2 className="text-[0.68rem] font-bold uppercase tracking-[0.22em] text-gold-600">
                  About This Message
                </h2>
                <dl className="mt-4 space-y-3 text-sm">
                  {[
                    ["Date", formatDate(s.sermonDate)],
                    ["Speaker", s.speaker],
                    ["Scripture", s.scripture || "—"],
                    ["Category", s.category],
                    ["Format", [s.videoUrl && "Video", s.audioUrl && "Audio"].filter(Boolean).join(" · ") || "—"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-4 border-b border-navy-900/6 pb-2.5 last:border-0">
                      <dt className="font-semibold text-ink-500">{k}</dt>
                      <dd className="text-right font-semibold text-navy-900">{v}</dd>
                    </div>
                  ))}
                </dl>
                <div className="mt-5 flex flex-wrap gap-2.5 border-t border-navy-900/8 pt-5">
                  {s.videoUrl && (
                    <a href={s.videoUrl} target="_blank" rel="noopener noreferrer" className="btn-outline-dark !px-4 !py-2 text-xs">
                      Download Video
                    </a>
                  )}
                  {s.audioUrl && (
                    <a href={s.audioUrl} target="_blank" rel="noopener noreferrer" className="btn-outline-dark !px-4 !py-2 text-xs">
                      Download Audio
                    </a>
                  )}
                </div>
              </div>
            </Reveal>

            <Reveal delay={140}>
              <div className="card-surface p-6">
                <h2 className="text-[0.68rem] font-bold uppercase tracking-[0.22em] text-gold-600">
                  Share This Message
                </h2>
                <div className="mt-4 grid grid-cols-2 gap-2.5">
                  <a
                    href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-outline-dark !px-3 !py-2.5 text-xs"
                  >
                    Facebook
                  </a>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(`${s.title} — ${shareUrl}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-outline-dark !px-3 !py-2.5 text-xs"
                  >
                    WhatsApp
                  </a>
                  <a
                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(s.title)}&url=${encodeURIComponent(shareUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-outline-dark !px-3 !py-2.5 text-xs"
                  >
                    X / Twitter
                  </a>
                  <a
                    href={`mailto:?subject=${encodeURIComponent(s.title)}&body=${encodeURIComponent(`Thought I would share this message with you:\n\n${s.title} — ${shareUrl}`)}`}
                    className="btn-outline-dark !px-3 !py-2.5 text-xs"
                  >
                    Email
                  </a>
                </div>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="rounded-2xl bg-navy-900 p-6">
                <MiniIcon name="candle" className="h-7 w-7 text-gold-400" />
                <h2 className="mt-4 font-display text-xl text-cream-50">
                  Something landed?
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-cream-100/65">
                  Let us pray with you about what you heard, or plan a visit
                  to experience it in person.
                </p>
                <div className="mt-5 flex flex-col gap-2.5">
                  <Link href="/prayer" className="btn-gold !px-4 !py-2.5 text-xs">
                    Submit a Prayer Request
                  </Link>
                  <Link href="/visit" className="btn-ghost-light !px-4 !py-2.5 text-xs">
                    Plan Your Visit
                  </Link>
                </div>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}

function sqlPublished() {
  return sql`${sermonsTable.published} = true`;
}
