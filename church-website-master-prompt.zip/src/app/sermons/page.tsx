import type { Metadata } from "next";
import { and, asc, desc, ilike, isNotNull, ne, or, sql } from "drizzle-orm";
import Link from "next/link";
import { SermonCard } from "@/components/cards";
import { Reveal, MiniIcon } from "@/components/ui";
import { db } from "@/db";
import { sermons as sermonsTable } from "@/db/schema";

export const metadata: Metadata = {
  title: "Sermons — Watch, Listen, Grow",
  description:
    "Browse the REDEEM sermon library: latest messages, video sermons, audio sermons and the full archive. Search by title, speaker or Scripture.",
};

const CATEGORIES = [
  "Faith",
  "Prayer",
  "Purpose",
  "Leadership",
  "Community",
  "Family",
  "Relationships",
  "Holy Spirit",
  "Spiritual Growth",
  "Evangelism",
  "Youth",
];

export default async function SermonsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string; type?: string }>;
}) {
  const params = await searchParams;
  const q = (params.q ?? "").trim();
  const category = (params.category ?? "").trim();
  const type = (params.type ?? "").trim();

  const clauses = [sql`${sermonsTable.published} = true`];
  if (q) {
    const like = `%${q}%`;
    clauses.push(
      or(
        ilike(sermonsTable.title, like),
        ilike(sermonsTable.speaker, like),
        ilike(sermonsTable.scripture, like),
        ilike(sermonsTable.summary, like),
        ilike(sermonsTable.category, like),
      )!,
    );
  }
  if (category) clauses.push(sql`${sermonsTable.category} = ${category}`);
  if (type === "video") clauses.push(isNotNull(sermonsTable.videoUrl));
  if (type === "audio") clauses.push(isNotNull(sermonsTable.audioUrl));

  const results = await db
    .select()
    .from(sermonsTable)
    .where(and(...clauses))
    .orderBy(desc(sermonsTable.sermonDate));

  const filtering = Boolean(q || category || type);

  return (
    <>
      <section className="bg-navy-950 py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Sermon Library
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl">
              Words to carry through the week
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-cream-100/75">
              Every REDEEM message, available in video and audio. Search the
              archive, filter by series theme, or simply start with the latest.
            </p>
          </Reveal>

          {/* Search & filter */}
          <Reveal delay={120}>
            <form
              method="GET"
              action="/sermons"
              className="mt-10 grid gap-3 rounded-2xl border border-cream-50/10 bg-navy-900/60 p-4 sm:grid-cols-2 lg:grid-cols-4"
              role="search"
              aria-label="Search sermons"
            >
              <div className="relative lg:col-span-2">
                <label htmlFor="sermon-q" className="sr-only">Search sermons</label>
                <input
                  id="sermon-q"
                  name="q"
                  type="search"
                  defaultValue={q}
                  placeholder="Search by title, speaker, Scripture…"
                  className="w-full rounded-xl border border-cream-50/15 bg-navy-950/70 px-4 py-3 text-sm text-cream-50 placeholder:text-cream-100/40 focus:border-gold-500 focus:outline-none focus:ring-2 focus:ring-gold-500/25"
                />
              </div>
              <div>
                <label htmlFor="sermon-cat" className="sr-only">Filter by category</label>
                <select
                  id="sermon-cat"
                  name="category"
                  defaultValue={category}
                  className="w-full rounded-xl border border-cream-50/15 bg-navy-950/70 px-4 py-3 text-sm text-cream-50 focus:border-gold-500 focus:outline-none focus:ring-2 focus:ring-gold-500/25"
                >
                  <option value="">All categories</option>
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label htmlFor="sermon-type" className="sr-only">Filter by format</label>
                  <select
                    id="sermon-type"
                    name="type"
                    defaultValue={type}
                    className="w-full rounded-xl border border-cream-50/15 bg-navy-950/70 px-4 py-3 text-sm text-cream-50 focus:border-gold-500 focus:outline-none focus:ring-2 focus:ring-gold-500/25"
                  >
                    <option value="">All formats</option>
                    <option value="video">Video</option>
                    <option value="audio">Audio</option>
                  </select>
                </div>
                <button type="submit" className="btn-gold shrink-0 !px-5 !py-3 text-xs">
                  Search
                </button>
              </div>
            </form>
            {filtering && (
              <div className="mt-3 flex items-center gap-3 text-sm text-cream-100/60">
                <span>
                  {results.length} result{results.length === 1 ? "" : "s"}
                  {q ? ` for “${q}”` : ""}
                  {category ? ` in ${category}` : ""}
                  {type ? ` (${type})` : ""}
                </span>
                <Link href="/sermons" className="font-bold text-gold-400 hover:text-gold-300">
                  Clear filters
                </Link>
              </div>
            )}
          </Reveal>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container-redeem">
          {results.length === 0 ? (
            <Reveal>
              <div className="card-surface mx-auto flex max-w-xl flex-col items-center gap-3 p-14 text-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-navy-800 text-gold-400">
                  <MiniIcon name="note" className="h-6 w-6" />
                </span>
                <p className="font-display text-2xl text-navy-900">No sermons found</p>
                <p className="text-sm leading-relaxed text-ink-500">
                  {filtering
                    ? "Nothing matches those filters yet. Try a different search, or clear the filters to see the full archive."
                    : "New messages are published weekly. Check back soon."}
                </p>
                {filtering && (
                  <Link href="/sermons" className="btn-dark mt-2">
                    Clear All Filters
                  </Link>
                )}
              </div>
            </Reveal>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {results.map((s, i) => (
                <Reveal key={s.id} delay={(i % 3) * 80}>
                  <SermonCard sermon={s} />
                </Reveal>
              ))}
            </div>
          )}

          <Reveal className="mt-14">
            <div className="flex flex-col items-center gap-3 rounded-2xl border border-gold-500/25 bg-navy-900 p-10 text-center">
              <p className="font-display text-2xl text-cream-50">
                Missed a Sunday? Catch up anytime.
              </p>
              <p className="max-w-xl text-sm text-cream-100/65">
                Follow REDEEM on YouTube and never miss a message — new
                sermons are posted within 48 hours of the Sunday service.
                (Channel link to be connected.)
              </p>
              <Link href="/prayer" className="btn-gold mt-2">
                Pray About What You Heard
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
