import Link from "next/link";
import { Reveal, MiniIcon } from "@/components/ui";

export default function NotFound() {
  return (
    <section className="flex min-h-[70vh] items-center bg-navy-950 py-24">
      <div className="container-redeem text-center">
        <Reveal>
          <p className="eyebrow-light justify-center">
            <span className="gold-hairline" aria-hidden="true" />
            Page Not Found
            <span className="gold-hairline rotate-180" aria-hidden="true" />
          </p>
          <h1 className="mt-5 font-display text-6xl font-medium tracking-tight text-cream-50 sm:text-7xl">
            4<span className="text-gold-400">0</span>4
          </h1>
          <p className="mx-auto mt-6 max-w-md font-display text-xl italic leading-relaxed text-cream-100/80">
            “Even though I walk through the darkest valley, I will fear no
            evil — for you are with me.”
          </p>
          <p className="mt-2 text-[0.68rem] font-bold uppercase tracking-[0.24em] text-gold-400">
            Psalm 23:4
          </p>
          <p className="mx-auto mt-6 max-w-md text-sm leading-relaxed text-cream-100/60">
            This page seems to have wandered off. But you are not lost —
            here is the way back.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <Link href="/" className="btn-gold">
              <MiniIcon name="pin" className="h-4 w-4" />
              Take Me Home
            </Link>
            <Link href="/visit" className="btn-ghost-light">
              Plan Your Visit
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
