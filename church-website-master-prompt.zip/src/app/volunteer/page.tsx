import type { Metadata } from "next";
import Image from "next/image";
import { Reveal, SectionHeading, MiniIcon } from "@/components/ui";
import { VolunteerForm } from "@/components/forms";
import { img } from "@/lib/images";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Volunteer — Serve With Your Gifts at REDEEM",
  description:
    "Serve at REDEEM. Find your place in children's ministry, worship, media, outreach and more — every gift matters, and every server is trained.",
};

const areas = [
  { icon: "sun", title: "Children", body: "Sunday school teachers, camp helpers, check-in safety" },
  { icon: "flame", title: "Youth", body: "Youth night team, mentors, small-group hosts" },
  { icon: "note", title: "Worship", body: "Vocalists, musicians, lighting and sound" },
  { icon: "camera", title: "Media", body: "Photography, video, streaming, social content" },
  { icon: "hand", title: "Outreach", body: "Food drives, community partnerships, missions" },
  { icon: "heart", title: "Hospitality", body: "Welcome teams, first-timer greeters, cafe crew" },
];

export default function VolunteerPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-navy-950 py-24 lg:py-28">
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={img.volunteers} alt="" fill priority sizes="100vw" className="object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/60" />
        </div>
        <div className="container-redeem relative">
          <Reveal>
            <p className="eyebrow-light">
              <span className="gold-hairline" aria-hidden="true" />
              Volunteer
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.08] tracking-tight text-cream-50 sm:text-5xl lg:text-6xl">
              The church runs on people{" "}
              <em className="italic text-gold-400">like you</em>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-cream-100/75">
              No track record required. Every server at REDEEM was once a
              first-timer in their role — trained, mentored and welcomed in.
              Tell us where God is leading you, and we will find the fit.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-20 lg:py-24">
        <div className="container-redeem">
          <Reveal>
            <SectionHeading
              eyebrow="Where You Could Serve"
              title="Gifts, not obligations"
              intro="Here are the main areas. If your gift is not listed, that is not a problem — it is an opening."
              align="center"
            />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {areas.map((a, i) => (
              <Reveal key={a.title} delay={(i % 3) * 80} className="h-full">
                <div className="card-surface flex h-full items-start gap-4 p-6 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/40">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-navy-800 text-gold-400">
                    <MiniIcon name={a.icon} className="h-5 w-5" />
                  </span>
                  <div>
                    <h2 className="font-display text-lg font-medium text-navy-900">{a.title}</h2>
                    <p className="mt-1 text-sm leading-relaxed text-ink-500">{a.body}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="mt-16 grid gap-10 lg:grid-cols-[1fr_1.3fr]">
            <Reveal>
              <div className="h-full rounded-2xl bg-navy-900 p-8 sm:p-10">
                <h2 className="font-display text-2xl text-cream-50">What serving looks like here</h2>
                <ul className="mt-6 space-y-4 text-sm leading-relaxed text-cream-100/70">
                  {[
                    "A conversation first — we listen before we assign.",
                    "Training and mentorship in every role, at every level.",
                    "Background checks for all children's and youth roles.",
                    "A community of servers who cover for each other and celebrate each other.",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-3">
                      <svg className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" viewBox="0 0 10 10" fill="currentColor" aria-hidden="true">
                        <path d="M5 0L10 5L5 10L0 5Z" />
                      </svg>
                      {t}
                    </li>
                  ))}
                </ul>
                <p className="mt-8 border-t border-cream-50/10 pt-6 font-display text-lg italic text-cream-100/85">
                  “Each of you should use whatever gift you have received to
                  serve others.”
                </p>
                <p className="mt-2 text-[0.65rem] font-bold uppercase tracking-[0.24em] text-gold-400">
                  1 Peter 4:10
                </p>
              </div>
            </Reveal>
            <Reveal delay={100}>
              <div className="card-surface p-6 sm:p-8">
                <h2 className="font-display text-2xl font-medium text-navy-900">Tell us where to find you</h2>
                <p className="mt-2 text-sm text-ink-500">
                  Two minutes now saves weeks of wondering. A volunteer team
                  member will reply personally.
                </p>
                <div className="mt-6">
                  <VolunteerForm />
                </div>
                <p className="mt-6 text-xs text-ink-300">
                  Prefer to talk first?{" "}
                  <Link href="/contact" className="font-bold text-gold-700 hover:text-gold-600">
                    Contact our office
                  </Link>{" "}
                  — or browse{" "}
                  <Link href="/ministries" className="font-bold text-gold-700 hover:text-gold-600">
                    our ministries
                  </Link>
                  .
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}
