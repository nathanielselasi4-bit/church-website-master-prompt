import type { MetadataRoute } from "next";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  events as eventsTable,
  ministries as ministriesTable,
  sermons as sermonsTable,
} from "@/db/schema";
import { site } from "@/lib/site";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const lastModified = new Date();
  const staticRoutes: MetadataRoute.Sitemap = [
    "",
    "/about",
    "/about/leadership",
    "/services",
    "/sermons",
    "/events",
    "/ministries",
    "/visit",
    "/prayer",
    "/join",
    "/volunteer",
    "/contact",
    "/give",
    "/roadmap",
    "/privacy",
    "/terms",
  ].map((path) => ({
    url: `${site.url}${path || "/"}`,
    lastModified,
    changeFrequency: (path === "/" ? "weekly" : "monthly") as
      | "weekly"
      | "monthly",
    priority: path === "/" ? 1 : 0.7,
  }));

  try {
    const [sermons, events, ministries] = await Promise.all([
      db
        .select({ slug: sermonsTable.slug, date: sermonsTable.sermonDate })
        .from(sermonsTable)
        .where(sql`${sermonsTable.published} = true`),
      db.select({ slug: eventsTable.slug, date: eventsTable.eventDate }).from(eventsTable),
      db.select({ slug: ministriesTable.slug }).from(ministriesTable),
    ]);

    return [
      ...staticRoutes,
      ...sermons.map((s) => ({
        url: `${site.url}/sermons/${s.slug}`,
        lastModified: new Date(`${s.date}T00:00:00Z`),
        changeFrequency: "monthly" as const,
        priority: 0.6,
      })),
      ...events.map((e) => ({
        url: `${site.url}/events/${e.slug}`,
        lastModified: new Date(`${e.date}T00:00:00Z`),
        changeFrequency: "weekly" as const,
        priority: 0.6,
      })),
      ...ministries.map((m) => ({
        url: `${site.url}/ministries/${m.slug}`,
        lastModified,
        changeFrequency: "monthly" as const,
        priority: 0.6,
      })),
    ];
  } catch {
    return staticRoutes;
  }
}


