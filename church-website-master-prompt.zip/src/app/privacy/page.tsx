import type { Metadata } from "next";
import { Reveal } from "@/components/ui";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How REDEEM Church collects, uses and protects the information you share with us — prayer requests, registrations, newsletters and contact messages.",
};

export default function PrivacyPage() {
  return (
    <section className="py-20 lg:py-24">
      <div className="container-redeem max-w-3xl">
        <Reveal>
          <p className="eyebrow">
            <span className="gold-hairline" aria-hidden="true" />
            Privacy Policy
          </p>
          <h1 className="mt-4 font-display text-4xl font-medium tracking-tight text-navy-900">
            Your trust, treated like a guest
          </h1>
          <div className="mt-8 space-y-6 text-[0.95rem] leading-relaxed text-ink-700">
            <p>
              REDEEM Church (&quot;we&quot;, &quot;us&quot;) takes the
              information you share with us seriously. This policy explains
              what we collect, why, and how it is protected.
            </p>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">What we collect</h2>
              <p className="mt-2">
                Information you provide through our forms: prayer requests,
                contact messages, event registrations, volunteer applications,
                newsletter sign-ups and giving intentions (name, email, and
                optional phone, plus the content of your message). We do not
                collect card numbers or financial account details on this
                website.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Why we collect it</h2>
              <p className="mt-2">
                To respond to you, to pray with you, to coordinate events, to
                welcome you properly, and — where you subscribe — to send
                updates you asked for. Nothing you share is used for
                advertising.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Prayer request privacy</h2>
              <p className="mt-2">
                Prayer requests are visible only to the church prayer team.
                They are never published or shared publicly unless you
                explicitly consent, and you can withdraw a request at any time
                by contacting the church office.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Sharing &amp; security</h2>
              <p className="mt-2">
                We store submissions in a private database and do not sell or
                rent your information. We may share details with a third-party
                payment processor only for the purpose of processing a gift
                you authorize, over a secure (HTTPS) connection.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-medium text-navy-900">Your rights</h2>
              <p className="mt-2">
                You may request to see, correct, or delete the personal
                information we hold about you at any time. Contact the church
                office and we will assist you promptly.
              </p>
            </div>
            <p className="border-t border-navy-900/8 pt-6 text-sm text-ink-500">
              This is a sample privacy policy prepared for the REDEEM website
              and should be reviewed by the church (and, where appropriate, a
              legal advisor) before publication.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
