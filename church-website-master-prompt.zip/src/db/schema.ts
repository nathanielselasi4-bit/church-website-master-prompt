import {
  boolean,
  date,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/*  REDEEM content layer — CMS-friendly, no hard-coded content.        */
/* ------------------------------------------------------------------ */

export const sermons = pgTable("sermons", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  speaker: text("speaker").notNull(),
  sermonDate: date("sermon_date").notNull(),
  scripture: text("scripture").notNull().default(""),
  category: text("category").notNull().default("Faith"),
  summary: text("summary").notNull().default(""),
  description: text("description").notNull().default(""),
  videoUrl: text("video_url"),
  audioUrl: text("audio_url"),
  thumbnail: text("thumbnail").notNull().default(""),
  featured: boolean("featured").notNull().default(false),
  published: boolean("published").notNull().default(true),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  category: text("category").notNull().default("Church Life"),
  eventDate: date("event_date").notNull(),
  startTime: text("start_time").notNull().default(""),
  endTime: text("end_time").notNull().default(""),
  location: text("location").notNull().default(""),
  description: text("description").notNull().default(""),
  details: text("details").notNull().default(""),
  speaker: text("speaker").notNull().default(""),
  image: text("image").notNull().default(""),
  registrationOpen: boolean("registration_open").notNull().default(true),
  featured: boolean("featured").notNull().default(false),
});

export const ministries = pgTable("ministries", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  purpose: text("purpose").notNull().default(""),
  activities: text("activities").notNull().default(""),
  meetingInfo: text("meeting_info").notNull().default(""),
  leaderName: text("leader_name").notNull().default(""),
  leaderTitle: text("leader_title").notNull().default(""),
  image: text("image").notNull().default(""),
  iconKey: text("icon_key").notNull().default("heart"),
  sort: integer("sort").notNull().default(0),
});

export const leaders = pgTable("leaders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  bio: text("bio").notNull().default(""),
  responsibility: text("responsibility").notNull().default(""),
  sort: integer("sort").notNull().default(0),
});

/* ------------------------------ Forms ------------------------------ */

export const prayerRequests = pgTable("prayer_requests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default(""),
  email: text("email").notNull().default(""),
  phone: text("phone"),
  category: text("category").notNull().default("General"),
  message: text("message").notNull(),
  anonymous: boolean("anonymous").notNull().default(false),
  consent: boolean("consent").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  subject: text("subject").notNull().default("General"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  source: text("source").notNull().default("footer"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const eventRegistrations = pgTable("event_registrations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  attendees: integer("attendees").notNull().default(1),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const givingIntents = pgTable("giving_intents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }),
  frequency: text("frequency").notNull().default("one-time"),
  fund: text("fund").notNull().default("General Fund"),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const volunteers = pgTable("volunteers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  ministry: text("ministry").notNull().default("General"),
  availability: text("availability").notNull().default(""),
  motivation: text("motivation").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
